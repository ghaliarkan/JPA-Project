package controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import service.MstBarangSvc;
import service.MstKaryawanSvc;
import common.RestResponse;
import dto.MstBarangDto;
import dto.MstKaryawanDto;

@RestController
@RequestMapping(value="/karyawan")
public class KaryawanCtrl {

	@Autowired
	MstKaryawanSvc mstKaryawanSvc;
	
	@RequestMapping(value="/selectAll", method=RequestMethod.GET)
	public ResponseEntity<List<MstKaryawanDto>> selectAll()
	{
		List<MstKaryawanDto> list = mstKaryawanSvc.findAllKaryawan();
		return new ResponseEntity<List<MstKaryawanDto>>(list, HttpStatus.OK);
	}
	
	
	//CARA SIMPLE
	@RequestMapping(value="/selectAll2", method=RequestMethod.GET)
	public RestResponse selectAll2()
	{
		List<MstKaryawanDto> list = mstKaryawanSvc.findAllKaryawan();
		RestResponse status = new RestResponse();
		status.setData(list);
		status.setStatus("Oke");
		return status;
	}
	
	//MENCARI DATA PADA CUSTOMER, CARA PANGGILNYA = http://localhost:8080/training/cari?cari=e
	@RequestMapping(value="/cari", method=RequestMethod.GET)
	public RestResponse findKaryawan(@RequestParam("cari") String cari)
	{
		List<MstKaryawanDto> list = mstKaryawanSvc.findDataKaryawan(cari);
		RestResponse data = new RestResponse();
		data.setData(list);
		return data;
	}
	
	//SAVE DATA KE DATABASE MELALUI POSTMAN
	@RequestMapping(value="/save", method=RequestMethod.POST)
	public RestResponse saveKaryawan(@RequestBody MstKaryawanDto dto)
	{
		mstKaryawanSvc.save(dto);
		RestResponse status = new RestResponse();
		status.setStatus("Tambah Data Berhasil");
		return status;
	}
	
	//UPDATE DATA KE DATABASE MELALUI POSTMAN
	@RequestMapping(value="/update", method=RequestMethod.PUT)
	public RestResponse updateKaryawan(@RequestBody MstKaryawanDto dto)
	{
		mstKaryawanSvc.update(dto);;
		RestResponse status = new RestResponse();
		status.setStatus("UPDATE BERHASIL :");
		return status;
	}
	
	//DELETE DATA DI DATABASE MELALUI POSTMAN
	@RequestMapping(value="/delete/{kode}", method=RequestMethod.DELETE)
	public RestResponse deleteKaryawan(@PathVariable("kode") String kode)
	{
		MstKaryawanDto dto = new MstKaryawanDto();
		dto.setKodeKaryawan(kode);
		mstKaryawanSvc.delete(dto);;
		RestResponse status = new RestResponse();
		status.setStatus("DATA BERHASIL DIHAPUS");
		return status;
	}
}
