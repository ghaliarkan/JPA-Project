package controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import common.RestResponse;


import service.TrDetailPenjualanSvc;
import dto.TrDetailPenjualanDto;

@RestController
@RequestMapping(value="/detail")
public class TrDetailCtrl {

	@Autowired
	TrDetailPenjualanSvc trDetailPenjualanSvc;
	
	@RequestMapping(value="/selectAll", method=RequestMethod.GET)
	public ResponseEntity<List<TrDetailPenjualanDto>> selectAll()
	{
		List<TrDetailPenjualanDto> list = trDetailPenjualanSvc.findAllDetailPenjualan();
		return new ResponseEntity<List<TrDetailPenjualanDto>>(list, HttpStatus.OK);
	}
	
	
	//CARA SIMPLE
	@RequestMapping(value="/selectAll2", method=RequestMethod.GET)
	public List<TrDetailPenjualanDto> selectAll2()
	{
		List<TrDetailPenjualanDto> list = trDetailPenjualanSvc.findAllDetailPenjualan();
		return list;
	}
	
	//MENCARI DATA PADA CUSTOMER, CARA PANGGILNYA = http://localhost:8080/training/cari?cari=e
	@RequestMapping(value="/cari", method=RequestMethod.GET)
	public RestResponse findDetail(@RequestParam("cari") String cari)
	{
		
		List<TrDetailPenjualanDto> list = trDetailPenjualanSvc.findDataDetailPenjualan(cari);
		RestResponse data = new RestResponse();
		data.setData(list);
		return data;
	}
	
	//SAVE DATA KE DATABASE MELALUI POSTMAN
	@RequestMapping(value="/save", method=RequestMethod.POST)
	public RestResponse saveDetail(@RequestBody TrDetailPenjualanDto dto)
	{
		trDetailPenjualanSvc.save(dto);
		RestResponse status = new RestResponse();
		status.setStatus("Data berhasil diinput");
		return status;
	}
	
	//UPDATE DATA KE DATABASE MELALUI POSTMAN
	@RequestMapping(value="/update", method=RequestMethod.PUT)
	public RestResponse updateDetail(@RequestBody TrDetailPenjualanDto dto)
	{
		trDetailPenjualanSvc.update(dto);
		RestResponse status = new RestResponse();
		status.setStatus("Data berhasil di update");
		return status;
	}
	
	//DELETE DATA DI DATABASE MELALUI POSTMAN
	@RequestMapping(value="/delete/{kode}", method=RequestMethod.DELETE)
	public RestResponse deleteDetail(@PathVariable("kode") String kode)
	{
		TrDetailPenjualanDto dto = new TrDetailPenjualanDto();
		dto.setKodeDetail(kode);
		trDetailPenjualanSvc.delete(dto);
		RestResponse status = new RestResponse();
		status.setStatus("Data berhasil dihapus");
		return status;
	}
}
