package controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import common.RestResponse;
import dto.MstCustomerDto;
import entity.MstCustomer;
import entity.MstCustomerPK;
import service.MstCustomerSvc;

@RestController
@RequestMapping(value="/v2")
public class CustomerCtrl2 {


		//--->"hellodunia" ini yang akan dipanggil, cara panggilnya = http://localhost:8080/training/helloarkani
		@RequestMapping(value="/helloghali", method=RequestMethod.POST)
		public String hello()
		{
			return "hello world ghali ganteng";
		}
		
		//--->"hellodunia" ini yang akan dipanggil, cara panggilnya = http://localhost:8080/training/helloarkani/ganteng
		@RequestMapping(value="/helloarkani/{nama}", method=RequestMethod.GET)
		public String world(@PathVariable("nama") String nama)
		{
			return "hello world ghali " + nama;
		}
		
		//--->"hellodunia" ini yang akan dipanggil, cara panggilnya = http://localhost:8080/training/hellodunia?nama=ganteng kaleee
		@RequestMapping(value="/hellodunia", method=RequestMethod.GET) 	
		public String hellodunia(@RequestParam(value="nama", defaultValue="ganteng banget", required=true) String nama)
		{
			return "hello world ghali " + nama;
		}

		//--->"hellodunia" ini yang akan dipanggil, cara panggilnya = http://localhost:8080/training/hellodunia?nama=ganteng kaleee
		@RequestMapping(value="/hellodunia2", method=RequestMethod.POST) //--->"hellodunia" ini yang akan dipanggil, cara panggilnya = http://localhost:8080/training/hellodunia?nama=ganteng kaleee	
		public String hellodunia2(@RequestBody String nama)
		{
			return "hello world ghali " + nama;
		}
		
		@Autowired
		MstCustomerSvc mstCustomerSvc;
		
		@RequestMapping(value="/selectAll", method=RequestMethod.GET)
		public ResponseEntity<List<MstCustomerDto>> selectAll()
		{
			List<MstCustomerDto> list = mstCustomerSvc.findAllCustomer();
			return new ResponseEntity<List<MstCustomerDto>>(list, HttpStatus.OK);
		}
		
		
		//CARA SIMPLE
		@RequestMapping(value="/selectAll2", method=RequestMethod.GET)
		public RestResponse selectAll2()
		{
			List<MstCustomerDto> list = mstCustomerSvc.findAllCustomer();
			RestResponse status = new RestResponse();
			status.setData(list);
			return status;
		}
		
		//MENCARI DATA PADA CUSTOMER, CARA PANGGILNYA = http://localhost:8080/training/cari?cari=e
		@RequestMapping(value="/cari", method=RequestMethod.GET)
		public RestResponse findCustomer(@RequestParam("cari") String cari)
		{
			List<MstCustomerDto> list = mstCustomerSvc.findDataCustomer(cari);
			RestResponse data = new RestResponse();
			data.setData(list);
			return data;
		}
		
		//SAVE DATA KE DATABASE MELALUI POSTMAN
		@RequestMapping(value="/save", method=RequestMethod.POST)
		public RestResponse saveCustomer(@RequestBody MstCustomerDto dto)
		{
			RestResponse status = new RestResponse();
			try{
				String kode = String.valueOf(dto.getKodeCustomer());
				boolean ada = mstCustomerSvc.cekData(dto.getKodeCustomer());
				if(ada == true)
				{
					Map errors = validateInput(dto);
					if(!errors.isEmpty())
						{
							status.setStatus("Error");
							status.setErrors(errors);
						}
						else
						{
							mstCustomerSvc.save(dto);
							status.setStatus("UPDATE BERHASIL :");
						}

				}
				else 
				{
					status.setStatus("Data gagal diinput");
				}
			}
			catch (Exception e) 
			{
				// TODO: handle exception
				status.setStatus(e.getMessage());
				
			}
			
			return status;
		}
		
//		//UPDATE DATA KE DATABASE MELALUI POSTMAN VERSI GHALI
//		@RequestMapping(value="/update", method=RequestMethod.PUT)
//		public RestResponse updateCustomer(@RequestBody MstCustomerDto dto)
//		{
//			
//			RestResponse status = new RestResponse();
//			Map werror = validatePK(dto);
//			Map errors = validateInput(dto);
//			if(!werror.isEmpty())
//			{
//				status.setStatus("Error");
//				status.setErrors(werror);
//			}
//			else
//			{
//				if(!errors.isEmpty())
//				{
//					status.setStatus("Error");
//					status.setErrors(errors);
//				}
//				else
//				{
//					mstCustomerSvc.update(dto);
//					status.setStatus("UPDATE BERHASIL :");
//				}
//				
//			}
//			
//			return status;
//		}
		
		//UPDATE DATA KE DATABASE MELALUI POSTMAN
				@RequestMapping(value="/update", method=RequestMethod.PUT)
				public RestResponse updateCustomer(@RequestBody MstCustomerDto dto)
				{
					
					RestResponse status = new RestResponse();
					try{
						String kode = String.valueOf(dto.getKodeCustomer());
						boolean ada = mstCustomerSvc.cekData(dto.getKodeCustomer());
						if(ada == true)
						{
							Map errors = validateInput(dto);
							if(!errors.isEmpty())
								{
									status.setStatus("Error");
									status.setErrors(errors);
								}
								else
								{
									mstCustomerSvc.update(dto);
									status.setStatus("UPDATE BERHASIL :");
								}
	
						}
						else 
						{
							status.setStatus("Data gagal diupdate");
						}
					}
					catch (Exception e) 
					{
						// TODO: handle exception
						status.setStatus(e.getMessage());
						
					}
					
					return status;
				}
		
		//PENGGUNAAN DI DELETE
		@RequestMapping(value="/delete/{kodeCustomer}", method=RequestMethod.DELETE)
		public RestResponse deleteCustomer(@PathVariable("kodeCustomer") String kodeCustomer)
		{
			RestResponse status = new RestResponse();
			try{
				String kode = String.valueOf(kodeCustomer);
				boolean ada = mstCustomerSvc.cekData(kodeCustomer);
				if(ada == true)
				{
					MstCustomerDto mstCustomerDto = new MstCustomerDto();
					mstCustomerDto.setKodeCustomer(kodeCustomer);
					mstCustomerSvc.delete(mstCustomerDto);
					status.setStatus("Data berhasil dihapus");
					
				}
				else 
				{
					status.setStatus("Data gagal dihapus");
				}
			}
			catch (Exception e) 
			{
				// TODO: handle exception
				status.setStatus("Error");
				
			}
			
			return status;
		}
		
		private Map<String,String> validateInput(MstCustomerDto dto)
		{
			Map map = new HashMap<String,String>();
			if(dto.getAlamatCustomer().length() < 1)
			{
				map.put("alamatCustomer", "length must not empty");
			}
			if(dto.getEmailCustomer().length() < 1 || !dto.getEmailCustomer().contains("@"))
			{
				map.put("emailCustomer", "invalid email fomat");
			}
			if(dto.getJenisKelamin().length() < 1) //|| !dto.getJenisKelamin().equalsIgnoreCase("L") || !dto.getJenisKelamin().equalsIgnoreCase("P"))
			{
				map.put("jeniskelaminCustomer", "must be 'L', 'l', 'P', or 'p'");
			}
			if(dto.getKodeCustomer().length() < 1)
			{
				map.put("kodeCustomer", "must enter kodeCustomer");
			}
			if(dto.getKodeKota().length() < 1)
			{
				map.put("kodeKota", "must enter kodeKota");
			}
			if(dto.getNamaCustomer().length() < 1)
			{
				map.put("namaCustomer", "must enter namaCustomer");
			}
			if(dto.getNamaKota().length() < 1)
			{
				map.put("namaKota", "must enter namaKota");
			}
			return map;
		}
		
		
		private Map<String, String> validatePK(MstCustomerDto dto)
		{
			List<MstCustomerDto> object = mstCustomerSvc.findAllCustomer();
			Map map = new HashMap<>();
			for(MstCustomerDto pk : object)
			{
				System.out.println("Tes Kode : " + pk.getKodeCustomer());
				System.out.println("Dto Kode : " + dto.getKodeCustomer());
				if(dto.getKodeCustomer().isEmpty())
				{
					map.put("kodeCustomer", "kodeCustomer must not empty");
				}
				else if(dto.getKodeCustomer().valueOf(false) != pk.getKodeCustomer().valueOf(true))
				{
					map.put("kodeCustomer", "kodeCustomer is not match");
				}
			}
			
			return map;
		}
		
	}

