package controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import common.RestResponse;
import dto.TrDetailPenjualanDto;
import dto.TrHeaderPenjualanDto;
import service.TrDetailPenjualanSvc;
import service.TrHeaderPenjualanSvc;

@RestController
@RequestMapping(value="/header")
public class TrHeaderCtrl {
	
	@Autowired
	TrHeaderPenjualanSvc trHeaderPenjualanSvc;
	
	@RequestMapping(value="/selectAll", method=RequestMethod.GET)
	public ResponseEntity<List<TrHeaderPenjualanDto>> selectAll()
	{
		List<TrHeaderPenjualanDto> list = trHeaderPenjualanSvc.findAllHeaderPenjualan();
		return new ResponseEntity<List<TrHeaderPenjualanDto>>(list, HttpStatus.OK);
	}
	
	//CARA SIMPLE
		@RequestMapping(value="/selectAll2", method=RequestMethod.GET)
		public RestResponse selectAll2()
		{
			List<TrHeaderPenjualanDto> list = trHeaderPenjualanSvc.findAllHeaderPenjualan();
			RestResponse status = new RestResponse();
			status.setStatus("Ok");
			status.setData(list);
			return status;
		}

		//MENCARI DATA PADA CUSTOMER, CARA PANGGILNYA = http://localhost:8080/training/cari?cari=e
		@RequestMapping(value="/cari", method=RequestMethod.GET)
		public RestResponse findHeader(@RequestParam("cari") String cari)
		{
			
			List<TrHeaderPenjualanDto> list = trHeaderPenjualanSvc.findDataHeaderPenjualan(cari);
			RestResponse data = new RestResponse();
			data.setData(list);
			data.setStatus("Ok");
			return data;
		}
		
		//SAVE DATA KE DATABASE MELALUI POSTMAN
		@RequestMapping(value="/save", method=RequestMethod.POST)
		public RestResponse saveHeader(@RequestBody TrHeaderPenjualanDto dto)
		{
//			DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
//			try
//			{
//				df.setLenient(false);
//				//Date tglLahir = df.parse()
//			}
//			catch(Exception e)
//			{
//				
//			}
			
			trHeaderPenjualanSvc.save(dto);
			RestResponse status = new RestResponse();
			status.setStatus("Data berhasil diinput");
			return status;
		}
		
		//UPDATE DATA KE DATABASE MELALUI POSTMAN
		@RequestMapping(value="/update", method=RequestMethod.PUT)
		public RestResponse updateHeader(@RequestBody TrHeaderPenjualanDto dto)
		{
			trHeaderPenjualanSvc.update(dto);
			RestResponse status = new RestResponse();
			status.setStatus("Data berhasil di update");
			return status;
		}
		
		//DELETE DATA DI DATABASE MELALUI POSTMAN
		@RequestMapping(value="/delete/{kode}", method=RequestMethod.DELETE)
		public RestResponse deleteHeader(@PathVariable("kode") String kode)
		{
			TrHeaderPenjualanDto dto = new TrHeaderPenjualanDto();
			dto.setNoNota(kode);
			trHeaderPenjualanSvc.delete(dto);
			RestResponse status = new RestResponse();
			status.setStatus("Data berhasil dihapus");
			return status;
		}

}
