package controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import service.MstProvinsiSvc;
import service.MstSupplierSvc;
import common.RestResponse;
import dto.MstProvinsiDto;
import dto.MstSupplierDto;

@RestController
@RequestMapping(value="/supplier")
public class SupplierCtrl {

	@Autowired
	MstSupplierSvc mstSupplierSvc;
	
	@RequestMapping(value="/selectAll", method=RequestMethod.GET)
	public ResponseEntity<List<MstSupplierDto>> selectAll()
	{
		List<MstSupplierDto> list = mstSupplierSvc.findAllSupplier();
		return new ResponseEntity<List<MstSupplierDto>>(list, HttpStatus.OK);
	}
	
	
	//CARA SIMPLE
	@RequestMapping(value="/selectAll2", method=RequestMethod.GET)
	public RestResponse selectAll2()
	{
		List<MstSupplierDto> list = mstSupplierSvc.findAllSupplier();
		RestResponse data = new RestResponse();
		data.setData(list);
		return data;
	}
	
	//MENCARI DATA PADA CUSTOMER, CARA PANGGILNYA = http://localhost:8080/training/cari?cari=e
	@RequestMapping(value="/cari", method=RequestMethod.GET)
	public RestResponse findSupplier(@RequestParam("cari") String cari)
	{
		List<MstSupplierDto> list = mstSupplierSvc.findDataSupplier(cari);
		RestResponse data = new RestResponse();
		data.setData(list);
		return data;
	}
	
	//SAVE DATA KE DATABASE MELALUI POSTMAN
	@RequestMapping(value="/save", method=RequestMethod.POST)
	public RestResponse saveSupplier(@RequestBody MstSupplierDto dto)
	{
		mstSupplierSvc.save(dto);
		RestResponse status = new RestResponse();
		status.setStatus("Tambah Data Berhasil");
		return status;
	}
	
	//UPDATE DATA KE DATABASE MELALUI POSTMAN
	@RequestMapping(value="/update", method=RequestMethod.PUT)
	public RestResponse updateProvinsi(@RequestBody MstSupplierDto dto)
	{
		mstSupplierSvc.update(dto);;
		RestResponse status = new RestResponse();
		status.setStatus("UPDATE BERHASIL :");
		return status;
	}
	
	//DELETE DATA DI DATABASE MELALUI POSTMAN
	@RequestMapping(value="/delete/{kode}", method=RequestMethod.DELETE)
	public RestResponse deleteSupplier(@PathVariable("kode") String kode)
	{
		MstSupplierDto dto = new MstSupplierDto();
		dto.setKodeSupplier(kode);
		mstSupplierSvc.delete(dto);;
		RestResponse status = new RestResponse();
		status.setStatus("DATA BERHASIL DIHAPUS");
		return status;
	}

}
