package controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import dto.MstCustomerDto;
import service.MstCustomerSvc;

@RestController
public class CustomerCtl {

	//--->"hellodunia" ini yang akan dipanggil, cara panggilnya = http://localhost:8080/training/helloarkani
	@RequestMapping(value="/helloghali", method=RequestMethod.POST)
	public String hello()
	{
		return "hello world ghali ganteng";
	}
	
	//--->"hellodunia" ini yang akan dipanggil, cara panggilnya = http://localhost:8080/training/helloarkani/ganteng
	@RequestMapping(value="/helloarkani/{nama}", method=RequestMethod.GET)
	public String world(@PathVariable("nama") String nama)
	{
		return "hello world ghali " + nama;
	}
	
	//--->"hellodunia" ini yang akan dipanggil, cara panggilnya = http://localhost:8080/training/hellodunia?nama=ganteng kaleee
	@RequestMapping(value="/hellodunia", method=RequestMethod.GET) 	
	public String hellodunia(@RequestParam(value="nama", defaultValue="ganteng banget", required=true) String nama)
	{
		return "hello world ghali " + nama;
	}

	//--->"hellodunia" ini yang akan dipanggil, cara panggilnya = http://localhost:8080/training/hellodunia?nama=ganteng kaleee
	@RequestMapping(value="/hellodunia2", method=RequestMethod.POST) //--->"hellodunia" ini yang akan dipanggil, cara panggilnya = http://localhost:8080/training/hellodunia?nama=ganteng kaleee	
	public String hellodunia2(@RequestBody String nama)
	{
		return "hello world ghali " + nama;
	}
	
	@Autowired
	MstCustomerSvc mstCustomerSvc;
	
	@RequestMapping(value="/selectAll", method=RequestMethod.GET)
	public ResponseEntity<List<MstCustomerDto>> selectAll()
	{
		List<MstCustomerDto> list = mstCustomerSvc.findAllCustomer();
		return new ResponseEntity<List<MstCustomerDto>>(list, HttpStatus.OK);
	}
	
	
	//CARA SIMPLE
	@RequestMapping(value="/selectAll2", method=RequestMethod.GET)
	public List<MstCustomerDto> selectAll2()
	{
		List<MstCustomerDto> list = mstCustomerSvc.findAllCustomer();
		return list;
	}
	
	//MENCARI DATA PADA CUSTOMER, CARA PANGGILNYA = http://localhost:8080/training/cari?cari=e
	@RequestMapping(value="/cari", method=RequestMethod.GET)
	public List<MstCustomerDto> findCustomer(@RequestParam("cari") String cari)
	{
		List<MstCustomerDto> list = mstCustomerSvc.findDataCustomer(cari);
		return list;
	}
	
	//SAVE DATA KE DATABASE MELALUI POSTMAN
	@RequestMapping(value="/save", method=RequestMethod.POST)
	public String saveCustomer(@RequestBody MstCustomerDto dto)
	{
		mstCustomerSvc.save(dto);
		return "OK!!";
	}
	
	//UPDATE DATA KE DATABASE MELALUI POSTMAN
	@RequestMapping(value="/update", method=RequestMethod.PUT)
	public String updateCustomer(@RequestBody MstCustomerDto dto)
	{
		mstCustomerSvc.update(dto);;
		return "OK cuksss!!";
	}
	
	//DELETE DATA DI DATABASE MELALUI POSTMAN
	@RequestMapping(value="/delete/{kode}", method=RequestMethod.DELETE)
	public String deleteCustomer(@PathVariable("kode") String kode)
	{
		MstCustomerDto dto = new MstCustomerDto();
		dto.setKodeCustomer(kode);
		mstCustomerSvc.delete(dto);;
		return "OK cuksss!!";
	}
	
}
