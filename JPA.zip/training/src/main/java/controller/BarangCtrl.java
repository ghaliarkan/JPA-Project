package controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import service.MstBarangSvc;
import service.MstCustomerSvc;
import common.RestResponse;
import dto.MstBarangDto;
import dto.MstCustomerDto;

@RestController
@RequestMapping(value="/barang")
public class BarangCtrl {

	@Autowired
	MstBarangSvc mstBarangSvc;
	
	@RequestMapping(value="/selectAll", method=RequestMethod.GET)
	public ResponseEntity<List<MstBarangDto>> selectAll()
	{
		List<MstBarangDto> list = mstBarangSvc.findAllBarang();
		return new ResponseEntity<List<MstBarangDto>>(list, HttpStatus.OK);
	}
	
	
	//CARA SIMPLE
	@RequestMapping(value="/selectAll2", method=RequestMethod.GET)
	public RestResponse selectAll2()
	{
		List<MstBarangDto> list = mstBarangSvc.findAllBarang();
		RestResponse status = new RestResponse();
		status.setData(list);
		return status;
	}
	
	//MENCARI DATA PADA CUSTOMER, CARA PANGGILNYA = http://localhost:8080/training/cari?cari=e
	@RequestMapping(value="/cari", method=RequestMethod.GET)
	public RestResponse findBarang(@RequestParam("cari") String cari)
	{
		List<MstBarangDto> list = mstBarangSvc.findDataBarang(cari);
		RestResponse data = new RestResponse();
		data.setData(list);
		return data;
	}
	
	//SAVE DATA KE DATABASE MELALUI POSTMAN
	@RequestMapping(value="/save", method=RequestMethod.POST)
	public RestResponse saveBarang(@RequestBody MstBarangDto dto)
	{
		mstBarangSvc.save(dto);
		RestResponse status = new RestResponse();
		status.setStatus("Oke boy!!");
		return status;
	}
	
	//UPDATE DATA KE DATABASE MELALUI POSTMAN
	@RequestMapping(value="/update", method=RequestMethod.PUT)
	public RestResponse updateBarang(@RequestBody MstBarangDto dto)
	{
		mstBarangSvc.update(dto);;
		RestResponse status = new RestResponse();
		status.setStatus("UPDATE BERHASIL :");
		return status;
	}
	
	//DELETE DATA DI DATABASE MELALUI POSTMAN
	@RequestMapping(value="/delete/{kode}", method=RequestMethod.DELETE)
	public RestResponse deleteBarang(@PathVariable("kode") String kode)
	{
		MstBarangDto dto = new MstBarangDto();
		dto.setKodeBarang(kode);
		mstBarangSvc.delete(dto);;
		RestResponse status = new RestResponse();
		status.setStatus("DATA BERHASIL DIHAPUS");
		return status;
	}
}
