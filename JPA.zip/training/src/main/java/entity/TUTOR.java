package entity;

public class TUTOR {

	
	/*<-> import project
	<-> pilih maven - existing maven = cari foldernya
	<-> klik kanan propertis projek
	<-> pilih projek facet - ceklis jpa
	<-> pilih furtuher di bbawah
	<-> add connektion
	<-> test ping - finish
		- if gagal 
			- masuk ke sql server configurasi 
			- sql server nert conf 
			- protokol for namanya
			- tcp/Ip di enable
			- kemudian 2klik tcpip
			- ip adres ke paling bwh - dinamic hapus, port 1433



	<-> klik kakan projek - jpa - generate entiti n tabel
	<-> reneame model ke entity
		-
	<-> ganti objek pada tanggal menjadi date (OPSIONAL)

	<-> buat pk - new class namaPk ok
		- implemen serial
		- ketik private tipe id
		- buat geter seter hanya id
	<-> buat pakage dao
		- new interface
		- exten jparepository
		- isi entity mahasiswa dan mahasiswaPk
			- isi query select all
			- buat metod select all
	<-> buat pakage dto
		- new class
		- copi semua property di entity
		- buat geter seter
			- select all
	<-> test semua di main dulu coy
		- ternyata blm seting koneksi guys
		= buka src/main/resouce/meta-nif/spring/app-config
			- edit nama database, username sa, pass sa
	<-> buat pakage service
		- buat interface nya
			- isi apa aja yg mau di lakuin
	<-> buat pakage impl di dalam service
		- source ditambah /service
		- nama impl
		- buat class impl
			-add impl service sebelum ok
		- seting 
			- @Service(".....Svc")
			- @Transactional
			--> public class ....
			- @Autowired
			- private ....Dao ....Dao;
	<-> buata pakage controller
		- buat class controlernya
			- setting
				- @RestController
				- @RequestMapping(value="/v2")
				- public class ...Ctl 
				- @Autowired
				- private ....Svc ....Svc;
			- matiin zx nya

			- tambahin jacson di pom.xml
			- <!-- <dependency>
					<groupId>com.fasterxml.jackson.core</groupId>
					<artifactId>jackson-databind</artifactId>
					<version>${jackson.version}</version>
				</dependency> -->
	<-> edit yangdi web.xml
		- training/src/main/webapp/WEB-INF/web.xml
			- Comment dari <listener> ZK listener for session..... sampai </mimme-mapping> yang paling bawah
			- tambahkan / uncomen di bawah listener .... samopai ... session config
				<!-- <servlet>
			 		<servlet-name>dispatcher</servlet-name>
			 		<servlet-class>org.springframework.web.servlet.DispatcherServlet</servlet-class>
			 		<load-on-startup>1</load-on-startup>
			 	</servlet>
			 	<servlet-mapping>
			 		<servlet-name>dispatcher</servlet-name>
			 		<url-pattern>/</url-pattern>
			 	</servlet-mapping> -->

	<-> buat pakage common 
		- copas yg udah ada aja
	<-> setting tomcat
		- pilih new server
		- pilih tomcat 7
		- klik add - pilih direktory tomcatnya - ok
		- next - pilih projeknya
		- finish
	<->
*/


}
