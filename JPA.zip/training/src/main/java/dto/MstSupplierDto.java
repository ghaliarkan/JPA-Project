package dto;

import javax.persistence.Column;
import javax.persistence.Id;

public class MstSupplierDto {

	private String kodeSupplier;
	private String alamatSupplier;
	private String emailSupplier;
	private String kodeKota;
	private String namaSupplier;
	public String getKodeSupplier() {
		return kodeSupplier;
	}
	public void setKodeSupplier(String kodeSupplier) {
		this.kodeSupplier = kodeSupplier;
	}
	public String getAlamatSupplier() {
		return alamatSupplier;
	}
	public void setAlamatSupplier(String alamatSupplier) {
		this.alamatSupplier = alamatSupplier;
	}
	public String getEmailSupplier() {
		return emailSupplier;
	}
	public void setEmailSupplier(String emailSupplier) {
		this.emailSupplier = emailSupplier;
	}
	public String getKodeKota() {
		return kodeKota;
	}
	public void setKodeKota(String kodeKota) {
		this.kodeKota = kodeKota;
	}
	public String getNamaSupplier() {
		return namaSupplier;
	}
	public void setNamaSupplier(String namaSupplier) {
		this.namaSupplier = namaSupplier;
	}
	public String getTelpSupplier() {
		return telpSupplier;
	}
	public void setTelpSupplier(String telpSupplier) {
		this.telpSupplier = telpSupplier;
	}
	private String telpSupplier;
}
