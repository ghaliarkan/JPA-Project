package dto;

import javax.persistence.Column;
import javax.persistence.Id;

public class MstProvinsiDto {

	private String kodeProvinsi;
	public String getKodeProvinsi() {
		return kodeProvinsi;
	}
	public void setKodeProvinsi(String kodeProvinsi) {
		this.kodeProvinsi = kodeProvinsi;
	}
	public String getNamaProvinsi() {
		return namaProvinsi;
	}
	public void setNamaProvinsi(String namaProvinsi) {
		this.namaProvinsi = namaProvinsi;
	}
	private String namaProvinsi;
}
