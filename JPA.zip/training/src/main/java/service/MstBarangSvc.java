package service;

import java.util.List;

import dto.MstBarangDto;

public interface MstBarangSvc {
	public List<MstBarangDto> findAllBarang();
	public void save(MstBarangDto mstBarangDto);
	public void update(MstBarangDto mstBarangDto);
	public void delete(MstBarangDto mstBarangDto);
	public List<MstBarangDto> findDataBarang(String cari);
	//public MstBarangDto findOneBarang(String kodeBarang);

}
