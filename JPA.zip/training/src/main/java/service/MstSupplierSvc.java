package service;

import java.util.List;

import dto.MstSupplierDto;

public interface MstSupplierSvc {
	public List<MstSupplierDto> findAllSupplier();
	public void save(MstSupplierDto mstSupplierDto);
	public void update(MstSupplierDto mstSupplierDto);
	public void delete(MstSupplierDto mstSupplierDto);
	public List<MstSupplierDto> findDataSupplier(String cari);
}
