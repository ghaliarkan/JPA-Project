package service;

import java.util.List;

import dto.MstKotaDto;

public interface MstKotaSvc {
	public List<MstKotaDto> findAllKota();
	public void save(MstKotaDto mstKotaDto);
	public void update(MstKotaDto mstKotaDto);
	public void delete(MstKotaDto mstKotaDto);
	public List<MstKotaDto> findDataKota(String cari);
	public List<MstKotaDto> findKotaByProvinsi(String kodeProvinsi);
	public MstKotaDto findOneObjectKota(String kodeKota);
}
