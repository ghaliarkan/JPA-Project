package service;

import java.util.List;

import dto.TrHeaderPenjualanDto;

public interface TrHeaderPenjualanSvc {
	public List<TrHeaderPenjualanDto> findAllHeaderPenjualan();
	public void save(TrHeaderPenjualanDto mstHeaderPenjualan);
	public void update(TrHeaderPenjualanDto mstHeaderPenjualanDto);
	public void delete(TrHeaderPenjualanDto mstHeaderPenjualanDto);
	public List<TrHeaderPenjualanDto> findDataHeaderPenjualan(String cari);
	public List<TrHeaderPenjualanDto> findTransaksi();
	public TrHeaderPenjualanDto findOneHeader(String noNota);
}
