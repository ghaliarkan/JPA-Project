package service;

import java.util.List;

import org.springframework.data.repository.query.Param;

import dto.TrDetailPenjualanDto;
import entity.TrDetailPenjualan;

public interface TrDetailPenjualanSvc {
	public List<TrDetailPenjualanDto> findAllDetailPenjualan();
	public void save(TrDetailPenjualanDto mstDetailPenjualan);
	public void update(TrDetailPenjualanDto mstDetailPenjualanDto);
	public void delete(TrDetailPenjualanDto mstDetailPenjualanDto);
	public List<TrDetailPenjualanDto> findDataDetailPenjualan(String cari);
	public List<TrDetailPenjualanDto> findTrDetail (String cari);
	public TrDetailPenjualanDto findOneDetail(String kodeDetail);
}
