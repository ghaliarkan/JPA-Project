package service;

import java.util.List;

import dto.MstCustomerDto;
import dto.MstKotaDto;

public interface MstCustomerSvc {
	
	public List<MstCustomerDto> findAllCustomer();
	public void save(MstCustomerDto mstCustomerDto);
	public void update(MstCustomerDto mstCustomerDto);
	public void delete(MstCustomerDto mstCustomerDto);
	public List<MstCustomerDto> findDataCustomer(String cari);
	public String genderDescription(String jenisKelamin);
	public boolean cekData(String kodeCustomer);
	public MstCustomerDto findOneCustomer(String cari);
	public MstCustomerDto findOneObjectCustomer(String kodeCustomer);
}
