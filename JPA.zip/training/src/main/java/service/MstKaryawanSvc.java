package service;

import java.util.List;

import dto.MstKaryawanDto;

public interface MstKaryawanSvc {
	public List<MstKaryawanDto> findAllKaryawan();
	public void save(MstKaryawanDto mstKaryawanDto);
	public void update(MstKaryawanDto mstKaryawanDto);
	public void delete(MstKaryawanDto mstKaryawanDto);
	public List<MstKaryawanDto> findDataKaryawan(String cari);
}
