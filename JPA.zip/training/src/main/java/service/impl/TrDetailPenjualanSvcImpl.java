package service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import dao.TrDetailPenjualanDao;
import dto.MstCustomerDto;
import dto.TrDetailPenjualanDto;
import dto.TrHeaderPenjualanDto;
import entity.MstCustomer;
import entity.MstCustomerPK;
import entity.TrDetailPenjualan;
import entity.TrDetailPenjualanPK;
import entity.TrHeaderPenjualan;
import service.TrDetailPenjualanSvc;

@Service("trDetailPenjualanSvc")
@Transactional
public class TrDetailPenjualanSvcImpl implements TrDetailPenjualanSvc {

	@Autowired
	private TrDetailPenjualanDao trDetailDao;
	
	@Override
	public List<TrDetailPenjualanDto> findAllDetailPenjualan() {
		List<Object[]> objects = trDetailDao.findAllTrDetail();
		List<TrDetailPenjualanDto> trDetailDtos = new ArrayList<>();
		for(Object[] o : objects)
		{
			TrDetailPenjualanDto detailDto = new TrDetailPenjualanDto();
			TrDetailPenjualan detail = (TrDetailPenjualan) o[0];
			detailDto.setDiskon(detail.getDiskon());
			detailDto.setHargaSatuan(detail.getHargaSatuan());
			detailDto.setKodeBarang(detail.getKodeBarang());
			detailDto.setKodeDetail(detail.getKodeDetail());
			detailDto.setNoNota(detail.getNoNota());
			detailDto.setQty(detail.getQty());
			detailDto.setSubtotal(detail.getSubtotal());
			trDetailDtos.add(detailDto);
		}
		return trDetailDtos;
	}

	@Override
	public void save(TrDetailPenjualanDto mstDetailPenjualan) {
		TrDetailPenjualan trDetail = new TrDetailPenjualan();
		trDetail.setDiskon(mstDetailPenjualan.getDiskon());
		trDetail.setHargaSatuan(mstDetailPenjualan.getHargaSatuan());
		trDetail.setKodeBarang(mstDetailPenjualan.getKodeBarang());
		trDetail.setKodeDetail(mstDetailPenjualan.getKodeDetail());
		trDetail.setNoNota(mstDetailPenjualan.getNoNota());
		trDetail.setQty(mstDetailPenjualan.getQty());
		trDetail.setSubtotal(mstDetailPenjualan.getSubtotal());
		trDetailDao.save(trDetail);
	}

	@Override
	public void update(TrDetailPenjualanDto mstDetailPenjualanDto) {
		TrDetailPenjualanPK trDetailPK = new TrDetailPenjualanPK();
		trDetailPK.setKodeDetail(mstDetailPenjualanDto.getKodeDetail());
		
		TrDetailPenjualan trDetail = trDetailDao.findOne(trDetailPK);
		trDetail.setDiskon(mstDetailPenjualanDto.getDiskon());
		trDetail.setHargaSatuan(mstDetailPenjualanDto.getHargaSatuan());
		trDetail.setKodeBarang(mstDetailPenjualanDto.getKodeBarang());
		trDetail.setKodeDetail(mstDetailPenjualanDto.getKodeDetail());
		trDetail.setNoNota(mstDetailPenjualanDto.getNoNota());
		trDetail.setQty(mstDetailPenjualanDto.getQty());
		trDetail.setSubtotal(mstDetailPenjualanDto.getSubtotal());
		trDetailDao.save(trDetail);

	}

	@Override
	public void delete(TrDetailPenjualanDto mstDetailPenjualanDto) {
		TrDetailPenjualanPK detailPK = new TrDetailPenjualanPK();
		detailPK.setKodeDetail(mstDetailPenjualanDto.getKodeDetail());
		trDetailDao.delete(detailPK);

	}

	@Override
	public List<TrDetailPenjualanDto> findDataDetailPenjualan(String cari) {
		List<Object[]> objects = trDetailDao.findTrDetailBySearch("%"+cari+"%");
		List<TrDetailPenjualanDto> trDetailDtos = new ArrayList<>();
		for(Object[] o : objects)
		{
			TrDetailPenjualanDto detailDto = new TrDetailPenjualanDto();
			TrDetailPenjualan detail = (TrDetailPenjualan) o[0];
			detailDto.setDiskon(detail.getDiskon());
			detailDto.setHargaSatuan(detail.getHargaSatuan());
			detailDto.setKodeBarang(detail.getKodeBarang());
			detailDto.setKodeDetail(detail.getKodeDetail());
			detailDto.setNoNota(detail.getNoNota());
			detailDto.setQty(detail.getQty());
			detailDto.setSubtotal(detail.getSubtotal());
			trDetailDtos.add(detailDto);
		}
		return trDetailDtos;
	}

	@Override
	public List<TrDetailPenjualanDto> findTrDetail(String cari) {
		List<Object[]> trDetail = trDetailDao.findTrDetail(cari);
		List<TrDetailPenjualanDto> trDetailDtos = new ArrayList<>();
		for(Object[] o : trDetail)
		{
			TrDetailPenjualanDto trDetailDto = new TrDetailPenjualanDto();
			TrDetailPenjualan detail = (TrDetailPenjualan) o[0];
			String namaBarang = (String) o[1];
//			trDetailDto.setDiskon(detail.getDiskon());
//			trDetailDto.setHargaSatuan(detail.getHargaSatuan());
//			trDetailDto.setKodeBarang(detail.getKodeBarang());
//			trDetailDto.setKodeDetail(detail.getKodeDetail());
//			trDetailDto.setNoNota(detail.getKodeDetail());
//			trDetailDto.setQty(detail.getQty());
//			trDetailDto.setSubtotal(detail.getSubtotal());
//			trDetailDto.setNamaBarang(namaBarang);
			trDetailDto.setKodeDetail((String) o[0]);
			trDetailDto.setNamaBarang((String) o[1]);
			trDetailDto.setQty((int) o[2]);
			trDetailDto.setHargaSatuan((int) o[3]);
			trDetailDto.setDiskon((int) o[4]);
			trDetailDto.setSubtotal((int) o[5]);
			trDetailDtos.add(trDetailDto);
		}
		return trDetailDtos;
	}

	@Override
	public TrDetailPenjualanDto findOneDetail(String kodeDetail) {
		TrDetailPenjualan trDetail = trDetailDao.findOneDetail(kodeDetail);
		TrDetailPenjualanDto trDetailDto = new TrDetailPenjualanDto();
		if(trDetail != null)
		{
			trDetailDto.setDiskon(trDetail.getDiskon());
			trDetailDto.setHargaSatuan(trDetail.getHargaSatuan());
			trDetailDto.setKodeBarang(trDetail.getKodeBarang());
			trDetailDto.setKodeDetail(trDetail.getKodeDetail());
			trDetailDto.setNoNota(trDetail.getKodeDetail());
			trDetailDto.setQty(trDetail.getQty());
			trDetailDto.setSubtotal(trDetail.getSubtotal());
		}
		return trDetailDto;
	}

}
