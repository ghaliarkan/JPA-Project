package service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import dao.MstSupplierDao;
import dto.MstProvinsiDto;
import dto.MstSupplierDto;
import entity.MstCustomerPK;
import entity.MstProvinsi;
import entity.MstProvinsiPK;
import entity.MstSupplier;
import entity.MstSupplierPK;
import service.MstSupplierSvc;

@Service("mstSupplierSvc")
@Transactional
public class MstSupplierSvcImpl implements MstSupplierSvc{

	
	@Autowired
	private MstSupplierDao mstSupplierDao;
	
	@Override
	public List<MstSupplierDto> findAllSupplier() {
		List<MstSupplier> mstSupplier = mstSupplierDao.findAllSupplier();//buat ambil
		List<MstSupplierDto> mstSupplierDtos = new ArrayList<>();//buat nyimpen
		for(MstSupplier o : mstSupplier)
		{
			MstSupplierDto supplierDto = new MstSupplierDto();
			supplierDto.setAlamatSupplier(o.getAlamatSupplier());
			supplierDto.setEmailSupplier(o.getEmailSupplier());
			supplierDto.setNamaSupplier(o.getNamaSupplier());
			supplierDto.setKodeKota(o.getKodeKota());
			supplierDto.setKodeSupplier(o.getKodeSupplier());
			supplierDto.setTelpSupplier(o.getTelpSupplier());

			mstSupplierDtos.add(supplierDto);
		}
		return mstSupplierDtos;
	}

	@Override
	public void save(MstSupplierDto mstSupplierDto) {
		MstSupplier mstSupplier = new MstSupplier();
		mstSupplier.setAlamatSupplier(mstSupplierDto.getAlamatSupplier());
		mstSupplier.setEmailSupplier(mstSupplierDto.getEmailSupplier());
		mstSupplier.setKodeKota(mstSupplierDto.getKodeKota());
		mstSupplier.setKodeSupplier(mstSupplierDto.getKodeSupplier());
		mstSupplier.setNamaSupplier(mstSupplierDto.getNamaSupplier());
		mstSupplier.setTelpSupplier(mstSupplierDto.getTelpSupplier());
		mstSupplierDao.save(mstSupplier);
		
	}

	@Override
	public void update(MstSupplierDto mstSupplierDto) {
		MstSupplierPK mstSupplierPK = new MstSupplierPK();
		mstSupplierPK.setKodeSupplier(mstSupplierDto.getKodeSupplier());
		
		MstSupplier mstSupplier = new MstSupplier();
		mstSupplier.setAlamatSupplier(mstSupplierDto.getAlamatSupplier());
		mstSupplier.setEmailSupplier(mstSupplierDto.getEmailSupplier());
		mstSupplier.setKodeKota(mstSupplierDto.getKodeKota());
		mstSupplier.setKodeSupplier(mstSupplierDto.getKodeSupplier());
		mstSupplier.setNamaSupplier(mstSupplierDto.getNamaSupplier());
		mstSupplier.setTelpSupplier(mstSupplierDto.getTelpSupplier());
		mstSupplierDao.save(mstSupplier);
		
	}

	@Override
	public void delete(MstSupplierDto mstSupplierDto) {
		MstSupplierPK supplierPK = new MstSupplierPK();
		supplierPK.setKodeSupplier(mstSupplierDto.getKodeSupplier());
		mstSupplierDao.delete(supplierPK);
	}

	@Override
	public List<MstSupplierDto> findDataSupplier(String cari) {
		List<MstSupplier> mstSupplier = mstSupplierDao.findSupplierBySearch("%"+cari+"%");
		List<MstSupplierDto> mstSupplierDtos = new ArrayList<>();
		
		for(MstSupplier o : mstSupplier)
		{
			MstSupplierDto supplierDto = new MstSupplierDto();
			MstSupplier supplier = new MstSupplier();
			supplierDto.setAlamatSupplier(supplier.getAlamatSupplier());
			supplierDto.setEmailSupplier(supplier.getEmailSupplier());
			supplierDto.setKodeKota(supplier.getKodeKota());
			supplierDto.setKodeSupplier(supplier.getKodeSupplier());
			supplierDto.setNamaSupplier(supplier.getNamaSupplier());
			supplierDto.setTelpSupplier(supplier.getTelpSupplier());
			mstSupplierDtos.add(supplierDto);
		}
		return mstSupplierDtos;
	}

}
