package service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import dao.MstCustomerDao;
import dto.MstCustomerDto;
import dto.MstKotaDto;
import entity.MstCustomer;
import entity.MstCustomerPK;
import entity.MstKota;
import service.MstCustomerSvc;
@Service("mstCustomerSvc")
@Transactional
public class MstCustomerSvcImpl implements MstCustomerSvc {

	@Autowired
	private MstCustomerDao mstCustomerDao;
	
	@Override
	public List<MstCustomerDto> findAllCustomer() {
		// TODO Auto-generated method stub
		List<Object[]> objects = mstCustomerDao.findAllCustomer();
		List<MstCustomerDto> mstCustomerDtos = new ArrayList<>();
		for(Object[] o : objects)
		{
			MstCustomerDto customerDto = new MstCustomerDto();
			MstCustomer customer = (MstCustomer) o[0];
			String namaKota =(String) o[1];
			customerDto.setKodeCustomer(customer.getKodeCustomer());
			customerDto.setAlamatCustomer(customer.getAlamatCustomer());
			customerDto.setEmailCustomer(customer.getEmailCustomer());
			customerDto.setJenisKelamin(customer.getJenisKelamin());
			customerDto.setKodeKota(customer.getKodeKota());
			customerDto.setNamaCustomer(customer.getNamaCustomer());
			customerDto.setNamaKota(namaKota);
			mstCustomerDtos.add(customerDto);
		}
		
		return mstCustomerDtos;
	}

	@Override
	public void save(MstCustomerDto mstCustomerDto) {
		MstCustomer mstCustomer = new MstCustomer();
		mstCustomer.setKodeCustomer(mstCustomerDto.getKodeCustomer());
		mstCustomer.setNamaCustomer(mstCustomerDto.getNamaCustomer());
		mstCustomer.setAlamatCustomer(mstCustomerDto.getAlamatCustomer());
		mstCustomer.setEmailCustomer(mstCustomerDto.getEmailCustomer());
		mstCustomer.setJenisKelamin(mstCustomerDto.getJenisKelamin());
		mstCustomer.setKodeKota(mstCustomerDto.getKodeKota());
		mstCustomerDao.save(mstCustomer);

	}

	@Override
	public void update(MstCustomerDto mstCustomerDto) {
		MstCustomerPK mstCustomerPK = new MstCustomerPK();
		mstCustomerPK.setKodeCustomer(mstCustomerDto.getKodeCustomer());
		
		MstCustomer mstCustomer = mstCustomerDao.findOne(mstCustomerPK);
		mstCustomer.setKodeCustomer(mstCustomerDto.getKodeCustomer());
		mstCustomer.setAlamatCustomer(mstCustomerDto.getAlamatCustomer());
		mstCustomer.setEmailCustomer(mstCustomerDto.getEmailCustomer());
		mstCustomer.setJenisKelamin(mstCustomerDto.getJenisKelamin());
		mstCustomer.setKodeKota(mstCustomerDto.getKodeKota());
		mstCustomer.setNamaCustomer(mstCustomerDto.getNamaCustomer());
		mstCustomerDao.save(mstCustomer);

	}

	@Override
	public void delete(MstCustomerDto mstCustomerDto) {
		
		MstCustomerPK customerPK = new MstCustomerPK();
		customerPK.setKodeCustomer(mstCustomerDto.getKodeCustomer());
		mstCustomerDao.delete(customerPK);

	}

	@Override
	public List<MstCustomerDto> findDataCustomer(String cari) {
		List<Object[]> objects = mstCustomerDao.findCustomerBySearch("%"+cari+"%");
		List<MstCustomerDto> mstCustomerDtos = new ArrayList<>();
		for(Object[] o : objects)
		{
			MstCustomerDto customerDto = new MstCustomerDto();
			MstCustomer customer = (MstCustomer) o[0];
			String namaKota =(String) o[1];
			customerDto.setKodeCustomer(customer.getKodeCustomer());
			customerDto.setAlamatCustomer(customer.getAlamatCustomer());
			customerDto.setEmailCustomer(customer.getEmailCustomer());
			customerDto.setJenisKelamin(genderDescription(customer.getJenisKelamin()));
			customerDto.setKodeKota(customer.getKodeKota());
			customerDto.setNamaCustomer(customer.getNamaCustomer());
			customerDto.setNamaKota(namaKota);
			mstCustomerDtos.add(customerDto);
		}
		return mstCustomerDtos;
	}

	@Override
	public String genderDescription(String jenisKelamin) {
		// TODO Auto-generated method stub
		if(jenisKelamin.equalsIgnoreCase("L"))
		{
			return "Laki-Laki";
		}
		else if(jenisKelamin.equalsIgnoreCase("P"))
		{
			return "Perempuan";
		}
		return "Undefined";
	}

	@Override
	public boolean cekData(String kodeCustomer) {
		// TODO Auto-generated method stub
		MstCustomer mstCustomer = mstCustomerDao.findOneCustomers(kodeCustomer);
		if(mstCustomer != null)
		{
			return true;
		}
		return false;
	}

	@Override
	public MstCustomerDto findOneCustomer(String cari) {
		MstCustomer mstCustomer = mstCustomerDao.findOneCustomer(cari);
		MstCustomerDto mstCustomerDto = new MstCustomerDto();
		if(mstCustomer != null)
		{
			mstCustomerDto.setAlamatCustomer(mstCustomer.getAlamatCustomer());
			mstCustomerDto.setEmailCustomer(mstCustomer.getEmailCustomer());
			mstCustomerDto.setJenisKelamin(mstCustomer.getJenisKelamin());
			mstCustomerDto.setKodeCustomer(mstCustomer.getKodeCustomer());
			mstCustomerDto.setKodeKota(mstCustomer.getKodeKota());
			mstCustomerDto.setNamaCustomer(mstCustomer.getNamaCustomer());
			return mstCustomerDto;
		}
		return mstCustomerDto;
	}
	
	//UNTUK MENCARI NAMA KARYAWAN DI TRANSAKSI DETAIL
	@Override
	public MstCustomerDto findOneObjectCustomer(String kodeCustomer) {
		List<Object[]> mstCustomer = mstCustomerDao.findOneObjectCustomer(kodeCustomer);
		MstCustomerDto customerDto = new MstCustomerDto();		
		for(Object[] o : mstCustomer)
		{
			MstCustomer customer = (MstCustomer) o[0];
			customerDto.setAlamatCustomer(customer.getAlamatCustomer());
			customerDto.setEmailCustomer(customer.getEmailCustomer());
			customerDto.setJenisKelamin(customer.getJenisKelamin());
			customerDto.setKodeCustomer(customer.getKodeCustomer());
			customerDto.setKodeKota(customer.getKodeKota());
			customerDto.setNamaCustomer(customer.getNamaCustomer());
		}
		return customerDto;
	}

}
