package service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import dao.MstKotaDao;
import dto.MstKaryawanDto;
import dto.MstKotaDto;
import entity.MstCustomerPK;
import entity.MstKaryawan;
import entity.MstKota;
import entity.MstKotaPK;
import service.MstKotaSvc;
@Service("mstKotaSvc")
@Transactional
public class MstKotaSvcImpl implements MstKotaSvc {

	@Autowired
	private MstKotaDao mstKotaDao;
	
	@Override
	public List<MstKotaDto> findAllKota() {
		// TODO Auto-generated method stub
		List<MstKota> mstKota = mstKotaDao.findAllKota();//buat ambil
		List<MstKotaDto> mstKotaDtos = new ArrayList<>();//buat nyimpen
		for(MstKota o : mstKota)
		{
			MstKotaDto kotaDto = new MstKotaDto();
			kotaDto.setKodeKota(o.getKodeKota());
			kotaDto.setKodeProvinsi(o.getKodeProvinsi());
			kotaDto.setNamaKota(o.getNamaKota());

			mstKotaDtos.add(kotaDto);
		}
		return mstKotaDtos;
	}

	@Override
	public void save(MstKotaDto mstKotaDto) {
		MstKota mstKota = new MstKota();
		mstKota.setKodeKota(mstKotaDto.getKodeKota());
		mstKota.setKodeProvinsi(mstKotaDto.getKodeProvinsi());
		mstKota.setNamaKota(mstKotaDto.getNamaKota());
		mstKotaDao.save(mstKota);
		
	}

	@Override
	public void update(MstKotaDto mstKotaDto) {
		MstKotaPK mstKotaPK = new MstKotaPK();
		mstKotaPK.setKodeKota(mstKotaDto.getKodeKota());
		
		MstKota mstKota = mstKotaDao.findOne(mstKotaPK);
		mstKota.setKodeKota(mstKotaDto.getKodeKota());
		mstKota.setKodeProvinsi(mstKotaDto.getKodeProvinsi());
		mstKota.setNamaKota(mstKotaDto.getNamaKota());
		mstKotaDao.save(mstKota);
	}

	@Override
	public void delete(MstKotaDto mstKotaDto) {
		MstKotaPK kotaPK = new MstKotaPK();
		kotaPK.setKodeKota(mstKotaDto.getKodeKota());
		mstKotaDao.delete(kotaPK);
		
	}

	@Override
	public List<MstKotaDto> findDataKota(String cari) {
		List<MstKota> mstKota = mstKotaDao.findKotaBySearch("%"+cari+"%");
		List<MstKotaDto> mstKotaDtos = new ArrayList<>();
		
		for(MstKota o : mstKota)
		{
			MstKotaDto kotaDto = new MstKotaDto();
			MstKota kota = new MstKota();
			kotaDto.setKodeKota(kota.getKodeKota());
			kotaDto.setKodeProvinsi(kota.getKodeProvinsi());
			kotaDto.setNamaKota(kota.getNamaKota());
			mstKotaDtos.add(kotaDto);
		}
		return mstKotaDtos;
	}

	@Override
	public List<MstKotaDto> findKotaByProvinsi(String kodeProvinsi) {
		List<Object[]> mstKota = mstKotaDao.findKotaByProvinsi(kodeProvinsi);
		List<MstKotaDto> mstKotaDtos = new ArrayList<>();
		
		for(Object[] o : mstKota)
		{
			MstKotaDto kotaDto = new MstKotaDto();
			MstKota kota = (MstKota) o[0];
			kotaDto.setKodeKota(kota.getKodeKota());
			kotaDto.setKodeProvinsi(kota.getKodeProvinsi());
			kotaDto.setNamaKota(kota.getNamaKota());
			mstKotaDtos.add(kotaDto);
		}
		return mstKotaDtos;
	}

	@Override
	public MstKotaDto findOneObjectKota(String kodeKota) {
		List<Object[]> mstKota = mstKotaDao.findOneObjectKota(kodeKota);
		MstKotaDto kotaDto = new MstKotaDto();		
		for(Object[] o : mstKota)
		{
			MstKota kota = (MstKota) o[0];
			kotaDto.setKodeKota(kota.getKodeKota());
			kotaDto.setKodeProvinsi(kota.getKodeProvinsi());
			kotaDto.setNamaKota(kota.getNamaKota());
			kotaDto.setNamaProvinsi((String) o[1]);
		}
		return kotaDto;
	}

}
