package service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import dao.MstProvinsiDao;
import dto.MstKotaDto;
import dto.MstProvinsiDto;
import entity.MstCustomerPK;
import entity.MstKota;
import entity.MstProvinsi;
import entity.MstProvinsiPK;
import service.MstProvinsiSvc;
@Service("mstProvinsiSvc")
@Transactional
public class MstProvinsiSvcImpl implements MstProvinsiSvc{

	@Autowired
	private MstProvinsiDao mstProvinsiDao;
	
	@Override
	public List<MstProvinsiDto> findAllProvinsi() {
		List<MstProvinsi> mstProvinsi = mstProvinsiDao.findAllProvinsi();//buat ambil
		List<MstProvinsiDto> mstProvinsiDtos = new ArrayList<>();//buat nyimpen
		for(MstProvinsi o : mstProvinsi)
		{
			MstProvinsiDto provinsiDto = new MstProvinsiDto();
			provinsiDto.setKodeProvinsi(o.getKodeProvinsi());
			provinsiDto.setNamaProvinsi(o.getNamaProvinsi());

			mstProvinsiDtos.add(provinsiDto);
		}
		return mstProvinsiDtos;
	}

	@Override
	public void save(MstProvinsiDto mstProvinsiDto) {
		MstProvinsi mstProvinsi = new MstProvinsi();
		mstProvinsi.setKodeProvinsi(mstProvinsiDto.getKodeProvinsi());
		mstProvinsi.setNamaProvinsi(mstProvinsiDto.getNamaProvinsi());
		mstProvinsiDao.save(mstProvinsi);
		
	}

	@Override
	public void update(MstProvinsiDto mstProvinsiDto) {
		MstProvinsiPK mstProvinsiPK = new MstProvinsiPK();
		mstProvinsiPK.setKodeProvinsi(mstProvinsiDto.getKodeProvinsi());
		
		MstProvinsi mstProvinsi = mstProvinsiDao.findOne(mstProvinsiPK);
		mstProvinsi.setKodeProvinsi(mstProvinsiDto.getKodeProvinsi());
		mstProvinsi.setNamaProvinsi(mstProvinsiDto.getNamaProvinsi());
		mstProvinsiDao.save(mstProvinsi);
		
	}

	@Override
	public void delete(MstProvinsiDto mstProvinsiDto) {
		MstProvinsiPK provinsiPK = new MstProvinsiPK();
		provinsiPK.setKodeProvinsi(mstProvinsiDto.getKodeProvinsi());
		mstProvinsiDao.delete(provinsiPK);
	}

	@Override
	public List<MstProvinsiDto> findDataProvinsi(String cari) {
		List<MstProvinsi> mstProvinsi = mstProvinsiDao.findProvinsiBySearch("%"+cari+"%");
		List<MstProvinsiDto> mstProvinsiDtos = new ArrayList<>();
		
		for(MstProvinsi o : mstProvinsi)
		{
			MstProvinsiDto provinsiDto = new MstProvinsiDto();
			MstProvinsi provinsi = new MstProvinsi();
			provinsiDto.setKodeProvinsi(provinsi.getKodeProvinsi());
			provinsiDto.setNamaProvinsi(provinsi.getNamaProvinsi());
			mstProvinsiDtos.add(provinsiDto);
		}
		return mstProvinsiDtos;
	}

	@Override
	public MstProvinsiDto findOne(String kodeProvinsi) {
		// TODO Auto-generated method stub
		MstProvinsiDto mstProvinsiDto = new MstProvinsiDto();
		MstProvinsiPK mstProvinsiPK = new MstProvinsiPK();
		mstProvinsiPK.setKodeProvinsi(kodeProvinsi);
		MstProvinsi provinsi = mstProvinsiDao.findOne(mstProvinsiPK);
		mstProvinsiDto.setKodeProvinsi(provinsi.getKodeProvinsi());
		mstProvinsiDto.setNamaProvinsi(provinsi.getNamaProvinsi());
		return mstProvinsiDto;
	}

}
