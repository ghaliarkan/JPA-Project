package service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import dao.MstKaryawanDao;
import dto.MstKaryawanDto;
import dto.MstKaryawanDto;
import entity.MstKaryawan;
import entity.MstKaryawanPK;
import service.MstKaryawanSvc;

@Service("mstKaryawanSvc")
@Transactional
public class MstKaryawanSvcImpl implements MstKaryawanSvc{

	@Autowired
	private MstKaryawanDao mstKaryawanDao;
	
	@Override
	public List<MstKaryawanDto> findAllKaryawan() {
		
		List<MstKaryawan> mstKaryawan = mstKaryawanDao.findAllKaryawan();//buat ambil
		List<MstKaryawanDto> mstKaryawanDtos = new ArrayList<>();//buat nyimpen
		for(MstKaryawan o : mstKaryawan)
		{
			MstKaryawanDto karyawanDto = new MstKaryawanDto();
			karyawanDto.setKodeKaryawan(o.getKodeKaryawan());
			karyawanDto.setNamaKaryawan(o.getNamaKaryawan());
			karyawanDto.setPassword(o.getPassword());
			karyawanDto.setUsername(o.getUsername());
			mstKaryawanDtos.add(karyawanDto);
		}
		return mstKaryawanDtos;
	}

	@Override
	public void save(MstKaryawanDto mstKaryawanDto) {
		MstKaryawan mstKaryawan = new MstKaryawan();
		mstKaryawan.setKodeKaryawan(mstKaryawanDto.getKodeKaryawan());
		mstKaryawan.setNamaKaryawan(mstKaryawanDto.getNamaKaryawan());
		mstKaryawan.setPassword(mstKaryawanDto.getPassword());
		mstKaryawan.setUsername(mstKaryawanDto.getUsername());
		mstKaryawanDao.save(mstKaryawan);		
	}

	@Override
	public void update(MstKaryawanDto mstKaryawanDto) {
		MstKaryawanPK mstKaryawanPK = new MstKaryawanPK();
		mstKaryawanPK.setKodeKaryawan(mstKaryawanDto.getKodeKaryawan());
		
		MstKaryawan mstKaryawan = mstKaryawanDao.findOne(mstKaryawanPK);
		mstKaryawan.setKodeKaryawan(mstKaryawanDto.getKodeKaryawan());
		mstKaryawan.setNamaKaryawan(mstKaryawanDto.getNamaKaryawan());
		mstKaryawan.setPassword(mstKaryawanDto.getPassword());
		mstKaryawan.setUsername(mstKaryawanDto.getUsername());
		mstKaryawanDao.save(mstKaryawan);
		
	}

	@Override
	public void delete(MstKaryawanDto mstKaryawanDto) {
		MstKaryawanPK karyawanPK = new MstKaryawanPK();
		karyawanPK.setKodeKaryawan(mstKaryawanDto.getKodeKaryawan());
		mstKaryawanDao.delete(karyawanPK);
		
	}

	@Override
	public List<MstKaryawanDto> findDataKaryawan(String cari) {
		List<MstKaryawan> mstKaryawan = mstKaryawanDao.findKaryawanBySearch("%"+cari+"%");
		List<MstKaryawanDto> mstKaryawanDtos = new ArrayList<>();
		
		for(MstKaryawan o : mstKaryawan)
		{
			MstKaryawanDto karyawanDto = new MstKaryawanDto();
			MstKaryawan karyawan = new MstKaryawan();
			karyawanDto.setKodeKaryawan(karyawan.getKodeKaryawan());
			karyawanDto.setNamaKaryawan(karyawan.getNamaKaryawan());
			karyawanDto.setPassword(karyawan.getPassword());
			karyawanDto.setUsername(karyawan.getUsername());
			mstKaryawanDtos.add(karyawanDto);
		}
		return mstKaryawanDtos;
	}

}
