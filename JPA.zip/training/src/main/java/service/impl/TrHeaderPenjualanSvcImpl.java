package service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import dao.TrHeaderPenjualanDao;
import dto.MstCustomerDto;
import dto.TrHeaderPenjualanDto;
import entity.MstCustomer;
import entity.TrHeaderPenjualan;
import entity.TrHeaderPenjualanPK;
import service.TrHeaderPenjualanSvc;

@Service("trHeaderPenjualanSvc")
@Transactional
public class TrHeaderPenjualanSvcImpl implements TrHeaderPenjualanSvc {

	@Autowired
	private TrHeaderPenjualanDao trHeaderDao;
	
	@Override
	public List<TrHeaderPenjualanDto> findAllHeaderPenjualan() {
		List<Object[]> objects = trHeaderDao.findAllTrHeader();
		List<TrHeaderPenjualanDto> trHeaderDtos = new ArrayList<>();
		for(Object[] o : objects)
		{
			TrHeaderPenjualanDto headerDto = new TrHeaderPenjualanDto();
			TrHeaderPenjualan header = (TrHeaderPenjualan) o[0];
			headerDto.setGlobalDiskon(header.getGlobalDiskon());
			headerDto.setHargaTotal(header.getHargaTotal());
			headerDto.setKodeCustomer(header.getKodeCustomer());
			headerDto.setKodeKaryawan(header.getKodeKaryawan());
			headerDto.setNoNota(header.getNoNota());
			headerDto.setTanggalTransaksi(header.getTanggalTransaksi());
			trHeaderDtos.add(headerDto);
		}
		return trHeaderDtos;
	}

	@Override
	public void save(TrHeaderPenjualanDto mstHeaderPenjualan) {
		TrHeaderPenjualan trHeader = new TrHeaderPenjualan();
		trHeader.setGlobalDiskon(mstHeaderPenjualan.getGlobalDiskon());
		trHeader.setHargaTotal(mstHeaderPenjualan.getHargaTotal());
		trHeader.setKodeCustomer(mstHeaderPenjualan.getKodeCustomer());
		trHeader.setKodeKaryawan(mstHeaderPenjualan.getKodeKaryawan());
		trHeader.setNoNota(mstHeaderPenjualan.getNoNota());
		trHeader.setTanggalTransaksi(mstHeaderPenjualan.getTanggalTransaksi());
		trHeaderDao.save(trHeader);

	}

	@Override
	public void update(TrHeaderPenjualanDto mstHeaderPenjualanDto) {
		TrHeaderPenjualanPK trHeaderPK = new TrHeaderPenjualanPK();
		trHeaderPK.setNoNota(mstHeaderPenjualanDto.getNoNota());
		
		TrHeaderPenjualan trHeader = trHeaderDao.findOne(trHeaderPK);
		trHeader.setGlobalDiskon(mstHeaderPenjualanDto.getGlobalDiskon());
		trHeader.setHargaTotal(mstHeaderPenjualanDto.getHargaTotal());
		trHeader.setKodeCustomer(mstHeaderPenjualanDto.getKodeCustomer());
		trHeader.setKodeKaryawan(mstHeaderPenjualanDto.getKodeKaryawan());
		trHeader.setNoNota(mstHeaderPenjualanDto.getNoNota());
		trHeader.setTanggalTransaksi(mstHeaderPenjualanDto.getTanggalTransaksi());
		trHeaderDao.save(trHeader);

	}

	@Override
	public void delete(TrHeaderPenjualanDto mstHeaderPenjualanDto) {
		TrHeaderPenjualanPK trHeaderPK = new TrHeaderPenjualanPK();
		trHeaderPK.setNoNota(mstHeaderPenjualanDto.getNoNota());
		trHeaderDao.delete(trHeaderPK);

	}

	@Override
	public List<TrHeaderPenjualanDto> findDataHeaderPenjualan(String cari) {
		List<Object[]> objects = trHeaderDao.findTrHeaderBySearch("%"+cari+"%");
		List<TrHeaderPenjualanDto> trHeaderDtos = new ArrayList<>();
		for(Object[] o : objects)
		{
			TrHeaderPenjualanDto headerDto = new TrHeaderPenjualanDto();
			TrHeaderPenjualan header = (TrHeaderPenjualan) o[0];
			String namaCustomer = (String) o[1];
			String namaKaryawan = (String) o[2];
			headerDto.setGlobalDiskon(header.getGlobalDiskon());
			headerDto.setHargaTotal(header.getHargaTotal());
			headerDto.setKodeCustomer(header.getKodeCustomer());
			headerDto.setKodeKaryawan(header.getKodeKaryawan());
			headerDto.setNoNota(header.getNoNota());
			headerDto.setTanggalTransaksi(header.getTanggalTransaksi());
			headerDto.setNamaCustomer(namaCustomer);
			headerDto.setNamaKaryawan(namaKaryawan);
			trHeaderDtos.add(headerDto);
		}
		return trHeaderDtos;
	}

	@Override
	public List<TrHeaderPenjualanDto> findTransaksi() {
		List<Object[]> objects = trHeaderDao.findTransaksi();
		List<TrHeaderPenjualanDto> trHeaderDtos = new ArrayList<>();
		for(Object[] o : objects)
		{
			TrHeaderPenjualanDto headerDto = new TrHeaderPenjualanDto();
			TrHeaderPenjualan header = (TrHeaderPenjualan) o[0];
			String namaCustomer = (String) o[1];
			String namaKaryawan = (String) o[2];
			headerDto.setGlobalDiskon(header.getGlobalDiskon());
			headerDto.setHargaTotal(header.getHargaTotal());
			headerDto.setKodeCustomer(header.getKodeCustomer());
			headerDto.setKodeKaryawan(header.getKodeKaryawan());
			headerDto.setNoNota(header.getNoNota());
			headerDto.setTanggalTransaksi(header.getTanggalTransaksi());
			headerDto.setNamaCustomer(namaCustomer);
			headerDto.setNamaKaryawan(namaKaryawan);
			trHeaderDtos.add(headerDto);
		}
		return trHeaderDtos;
	}

	@Override
	public TrHeaderPenjualanDto findOneHeader(String noNota) {
		TrHeaderPenjualan trHeader = trHeaderDao.findOneHeader(noNota);
		TrHeaderPenjualanDto trHeaderDto = new TrHeaderPenjualanDto();
		if(trHeader != null)
		{
			trHeaderDto.setGlobalDiskon(trHeader.getGlobalDiskon());
			trHeaderDto.setHargaTotal(trHeader.getHargaTotal());
			trHeaderDto.setKodeCustomer(trHeader.getKodeCustomer());
			trHeaderDto.setKodeKaryawan(trHeader.getKodeKaryawan());
			trHeaderDto.setNoNota(trHeader.getNoNota());
			trHeaderDto.setTanggalTransaksi(trHeader.getTanggalTransaksi());
			return trHeaderDto;
		}
		return trHeaderDto;
	}

}
