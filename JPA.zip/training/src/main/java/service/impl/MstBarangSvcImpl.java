package service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import dao.MstBarangDao;
import dto.MstBarangDto;
import dto.MstCustomerDto;
import entity.MstBarang;
import entity.MstBarangPK;
import entity.MstCustomer;
import entity.MstCustomerPK;
import service.MstBarangSvc;
@Service("mstBarangSvc")
@Transactional
public class MstBarangSvcImpl implements MstBarangSvc {

	@Autowired
	private MstBarangDao mstBarangDao;
	
	@Override
	public List<MstBarangDto> findAllBarang() {
		// TODO Auto-generated method stub
		List<Object[]> objects = mstBarangDao.findAllBarang();
		List<MstBarangDto> mstBarangDtos = new ArrayList<>();
		for(Object[] o : objects)
		{
			MstBarangDto barangDto = new MstBarangDto();
			MstBarang barang = (MstBarang) o[0];
			String namaSupplier =(String) o[1];
			barangDto.setKodeBarang(barang.getKodeBarang());
			barangDto.setKodeSupplier(barang.getKodeSupplier());
			barangDto.setNamaBarang(barang.getNamaBarang());
			barangDto.setStokBarang(barang.getStokBarang());
			barangDto.setNamaSupplier(namaSupplier);
			mstBarangDtos.add(barangDto);
		}
		
		return mstBarangDtos;
	}

	@Override
	public void save(MstBarangDto mstBarangDto) {
		MstBarang mstBarang = new MstBarang();
		mstBarang.setKodeBarang(mstBarangDto.getKodeBarang());
		mstBarang.setKodeSupplier(mstBarangDto.getKodeSupplier());
		mstBarang.setNamaBarang(mstBarangDto.getNamaBarang());
		mstBarang.setStokBarang(mstBarangDto.getStokBarang());
		mstBarangDao.save(mstBarang);
		
	}

	@Override
	public void update(MstBarangDto mstBarangDto) {
		MstBarangPK mstBarangPK = new MstBarangPK();
		mstBarangPK.setKodeBarang(mstBarangDto.getKodeBarang());
		
		MstBarang mstBarang = mstBarangDao.findOne(mstBarangPK);
		mstBarang.setKodeBarang(mstBarangDto.getKodeBarang());
		mstBarang.setKodeSupplier(mstBarangDto.getKodeSupplier());
		mstBarang.setNamaBarang(mstBarangDto.getNamaBarang());
		mstBarang.setStokBarang(mstBarangDto.getStokBarang());
		mstBarangDao.save(mstBarang);
	}

	@Override
	public void delete(MstBarangDto mstBarangDto) {
		MstBarangPK barangPK = new MstBarangPK();
		barangPK.setKodeBarang(mstBarangDto.getKodeBarang());
		mstBarangDao.delete(barangPK);
		
	}

	@Override
	public List<MstBarangDto> findDataBarang(String cari) {
		List<MstBarang> mstBarang = mstBarangDao.findBarangBySearch("%"+cari+"%");
		List<MstBarangDto> mstBarangDtos = new ArrayList<>();
		
		for(MstBarang o : mstBarang)
		{
			MstBarangDto barangDto = new MstBarangDto();
			MstBarang barang = new MstBarang();
			barangDto.setKodeBarang(barang.getKodeBarang());
			barangDto.setKodeSupplier(barang.getKodeSupplier());
			barangDto.setNamaBarang(barang.getNamaBarang());
			mstBarangDtos.add(barangDto);
		}
		return mstBarangDtos;
	}

//	@Override
//	public MstBarangDto findOneBarang(String kodeBarang) {
//		MstBarangPK barangPK = new MstBarangPK();
//		barangPK.setKodeBarang(mstBarangDto.getKodeBarang());
//		
//	}
	

}
