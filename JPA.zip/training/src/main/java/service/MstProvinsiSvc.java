package service;

import java.util.List;

import dto.MstProvinsiDto;

public interface MstProvinsiSvc {
	public List<MstProvinsiDto> findAllProvinsi();
	public void save(MstProvinsiDto mstProvinsiDto);
	public void update(MstProvinsiDto mstProvinsiDto);
	public void delete(MstProvinsiDto mstProvinsiDto);
	public List<MstProvinsiDto> findDataProvinsi(String cari);
	public MstProvinsiDto findOne (String kodeProvinsi);
}
