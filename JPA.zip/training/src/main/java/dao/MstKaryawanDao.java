package dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import entity.MstKaryawan;
import entity.MstKaryawanPK;

public interface MstKaryawanDao extends JpaRepository<MstKaryawan, MstKaryawanPK> {
	@Query("select a from MstKaryawan a")
	
	public List<MstKaryawan> findAllKaryawan();
	
	//CODE UNTUK MENCARI ORANG DALAM DATABASE, KONDISI DISESUAIKAN DI WHERE, BISA MENGGUNAKAN OR DAN AND
		@Query("select a from MstKaryawan a "
				+ "where a.kodeKaryawan = :tampung or a.namaKaryawan = :tampung")
		
		public MstKaryawan findOneBarang(@Param("tampung") String tampung); //--> FUNGSINYA HANYA UNTUK MENAMPUNG INPUTAN

		@Query("select a from MstKaryawan a "
				+ "where "
				+ "(a.kodeKaryawan like :cari "
				+ "or a.namaKaryawan like :cari)")
		
		public List<MstKaryawan> findKaryawanBySearch(@Param("cari")String cari);
}
