package dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import entity.MstCustomer;
import entity.MstCustomerPK;

public interface MstCustomerDao extends JpaRepository<MstCustomer, MstCustomerPK> {

	//CODE UNTUK MENCARI ORANG BERDASARKAN KODEKOTA
	@Query("select a,b.namaKota from MstCustomer a, MstKota b "
			+ "where a.kodeKota = b.kodeKota")
	
	public List<Object[]> findAllCustomer();
	
	//CODE UNTUK MENCARI ORANG DALAM DATABASE, KONDISI DISESUAIKAN DI WHERE, BISA MENGGUNAKAN OR DAN AND
	@Query("select a from MstCustomer a "
			+ "where a.kodeCustomer = :tampung or a.namaCustomer = :tampung")
	
	public MstCustomer findOneCustomer(@Param("tampung") String tampung); //--> FUNGSINYA HANYA UNTUK MENAMPUNG INPUTAN

	@Query("select a, b.namaKota from MstCustomer a, MstKota b "
			+ "where a.kodeKota = b.kodeKota AND "
			+ "(a.kodeCustomer like :cari "
			+ "or a.namaCustomer like :cari)")
	
	public List<Object[]> findCustomerBySearch(@Param("cari")String cari);
	
	@Query ("select a from MstCustomer a "
			+ "where a.kodeCustomer = :kodeCustomer")
	public MstCustomer findOneCustomers(@Param("kodeCustomer") String kodeCustomer);
	
	//UNTUK MENCARI NAMA KARYAWAN DI TRANSAKSI DETAIL
	@Query("select a, b.namaCustomer, c.namaKaryawan from TrHeaderPenjualan a, MstCustomer b, MstKaryawan c "
			+ "where a.kodeCustomer = b.kodeCustomer AND a.kodeKaryawan = c.kodeKaryawan AND "
			+ "b.kodeCustomer = :kodeCustomer")
	public List<Object[]> findOneObjectCustomer(@Param("kodeCustomer")String kodeCustomer);
}
