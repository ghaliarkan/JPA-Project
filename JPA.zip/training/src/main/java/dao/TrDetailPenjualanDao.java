package dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import entity.TrDetailPenjualan;
import entity.TrDetailPenjualanPK;
import entity.TrHeaderPenjualan;

public interface TrDetailPenjualanDao extends JpaRepository<TrDetailPenjualan, TrDetailPenjualanPK> {

	//CODE UNTUK MENCARI ORANG BERDASARKAN KODEKOTA
		@Query("select a,b from TrDetailPenjualan a, MstBarang b "
				+ "where a.kodeBarang = b.kodeBarang")
		
		public List<Object[]> findAllTrDetail();
		
		//CODE UNTUK MENCARI ORANG DALAM DATABASE, KONDISI DISESUAIKAN DI WHERE, BISA MENGGUNAKAN OR DAN AND
		@Query("select a from TrDetailPenjualan a "
				+ "where a.kodeDetail = :tampung")
		
		public TrDetailPenjualan findOneTrDetail(@Param("tampung") String tampung); //--> FUNGSINYA HANYA UNTUK MENAMPUNG INPUTAN

		@Query("select a, b from TrDetailPenjualan a, MstBarang b "
				+ "where a.kodeBarang = b.kodeBarang AND "
				+ "(a.kodeDetail like :cari "
				+ "or b.kodeBarang like :cari)")
		
		public List<Object[]> findTrDetailBySearch(@Param("cari")String cari);
		
		//AMBIL DATA BARANG
		@Query("select a.kodeDetail, b.namaBarang, a.qty, a.hargaSatuan, a.diskon, a.subtotal from TrDetailPenjualan a, MstBarang b "
				+ "where a.kodeBarang = b.kodeBarang AND "
				+ "a.noNota = :cari")
		public List<Object[]> findTrDetail(@Param("cari")String cari);
		
		//buat save di detail bawah
		@Query("select a from TrDetailPenjualan a where a.kodeDetail =:kodeDetail")
		public TrDetailPenjualan findOneDetail(@Param("kodeDetail")String kodeDetail);
}
