package dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import entity.MstKota;
import entity.MstKotaPK;

public interface MstKotaDao extends JpaRepository<MstKota, MstKotaPK>{
	
	@Query("select a from MstKota a")
	
	public List<MstKota> findAllKota();
	
	//CODE UNTUK MENCARI ORANG DALAM DATABASE, KONDISI DISESUAIKAN DI WHERE, BISA MENGGUNAKAN OR DAN AND
			@Query("select a from MstKota a "
					+ "where a.kodeKota = :tampung or a.namaKota = :tampung")
			public MstKota findOneKota(@Param("tampung") String tampung); //--> FUNGSINYA HANYA UNTUK MENAMPUNG INPUTAN

			@Query("select a from MstKota a "
					+ "where "
					+ "(a.kodeKota like :cari "
					+ "or a.namaKota like :cari)")
			public List<MstKota> findKotaBySearch(@Param("cari")String cari);
			
			@Query("select a, b.namaProvinsi from MstKota a, MstProvinsi b  "
					+ "where a.kodeProvinsi = b.kodeProvinsi AND "
					+ "a.kodeProvinsi =:kodeProvinsi ")
			public List<Object[]> findKotaByProvinsi(@Param("kodeProvinsi")String kodeProvinsi);

			@Query("select a, b.namaProvinsi from MstKota a, MstProvinsi b  "
					+ "where a.kodeProvinsi = b.kodeProvinsi AND "
					+ "a.kodeKota =:kodeKota ")
			public List<Object[]> findOneObjectKota(@Param("kodeKota")String kodeKota);
}
