package dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import entity.MstBarang;
import entity.MstBarangPK;

public interface MstBarangDao extends JpaRepository<MstBarang, MstBarangPK> {

	@Query("select barang, supplier.namaSupplier from MstBarang barang, MstSupplier supplier "
			+ "where barang.kodeSupplier = supplier.kodeSupplier")
	
	public List<Object[]> findAllBarang(); 
	
	//CODE UNTUK MENCARI ORANG DALAM DATABASE, KONDISI DISESUAIKAN DI WHERE, BISA MENGGUNAKAN OR DAN AND
		@Query("select a from MstBarang a "
				+ "where a.kodeBarang = :tampung or a.namaBarang = :tampung")
		
		public MstBarang findOneBarang(@Param("tampung") String tampung); //--> FUNGSINYA HANYA UNTUK MENAMPUNG INPUTAN

		@Query("select a from MstBarang a "
				+ "where "
				+ "a.kodeBarang like :cari "
				+ "or a.namaBarang like :cari")
		
		public List<MstBarang> findBarangBySearch(@Param("cari")String cari);
}
