package dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import entity.TrDetailPenjualan;
import entity.TrHeaderPenjualan;
import entity.TrHeaderPenjualanPK;

public interface TrHeaderPenjualanDao extends JpaRepository<TrHeaderPenjualan, TrHeaderPenjualanPK> {

	//CODE UNTUK MENCARI ORANG BERDASARKAN KODEKOTA
			@Query("select a,b from TrHeaderPenjualan a, MstCustomer b "
					+ "where a.kodeCustomer = b.kodeCustomer")
			
			public List<Object[]> findAllTrHeader();
			
			//CODE UNTUK MENCARI ORANG DALAM DATABASE, KONDISI DISESUAIKAN DI WHERE, BISA MENGGUNAKAN OR DAN AND
			@Query("select a from TrHeaderPenjualan a "
					+ "where a.noNota = :tampung")
			
			public TrHeaderPenjualan findOneTrHeader(@Param("tampung") String tampung); //--> FUNGSINYA HANYA UNTUK MENAMPUNG INPUTAN

			@Query("select a, b.namaCustomer, c.namaKaryawan from TrHeaderPenjualan a, MstCustomer b, MstKaryawan c "
					+ "where a.kodeCustomer = b.kodeCustomer AND a.kodeKaryawan = c.kodeKaryawan AND "
					+ "(a.noNota like :cari "
					+ "or b.namaCustomer like :cari or c.namaKaryawan like :cari)")
			public List<Object[]> findTrHeaderBySearch(@Param("cari")String cari);
			
			@Query("select a, b.namaCustomer, c.namaKaryawan from TrHeaderPenjualan a, MstCustomer b, MstKaryawan c "
					+ "where a.kodeCustomer = b.kodeCustomer and "
					+ "a.kodeKaryawan = c.kodeKaryawan")
			public List<Object[]> findTransaksi();
			
			//buat save di header atas
			@Query("select a from TrHeaderPenjualan a where a.noNota =:noNota")
			public TrHeaderPenjualan findOneHeader(@Param("noNota")String noNota);

			//buat nampung detail di list
			@Query("select a, b, c.namaBarang from TrHeaderPenjualan a, TrDetailPenjualan b, MstBarang c "
					+ "where a.noNota = b.noNota AND b.kodeBarang = c.kodeBarang "
					+ "AND a.noNota =:noNota")
			public List<Object[]> tampungDetail(@Param("noNota")String noNota);

}
