package dao;

import org.springframework.data.jpa.repository.JpaRepository;

import entity.MstCoba;

public interface MstCobaDao extends JpaRepository<MstCoba, Integer> {

}
