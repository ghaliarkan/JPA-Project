package dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import entity.MstSupplier;
import entity.MstSupplierPK;

public interface MstSupplierDao extends
		JpaRepository<MstSupplier, MstSupplierPK> {

	@Query("select a from MstSupplier a")
	public List<MstSupplier> findAllSupplier();

	// CODE UNTUK MENCARI ORANG DALAM DATABASE, KONDISI DISESUAIKAN DI WHERE,
	// BISA MENGGUNAKAN OR DAN AND
	@Query("select a from MstSupplier a "
			+ "where a.kodeSupplier = :tampung or a.namaSupplier = :tampung")
	public MstSupplier findOneSupplier(@Param("tampung") String tampung); // -->
																			// FUNGSINYA
																			// HANYA
																			// UNTUK
																			// MENAMPUNG
																			// INPUTAN

	@Query("select a from MstSupplier a " + "where "
			+ "(a.kodeSupplier like :cari " + "or a.namaSupplier like :cari)")
	public List<MstSupplier> findSupplierBySearch(@Param("cari") String cari);
}
