package main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import service.MstBarangSvc;
import service.MstCustomerSvc;
import service.MstKaryawanSvc;
import service.MstKotaSvc;
import service.MstProvinsiSvc;
import service.MstSupplierSvc;
import dao.MstBarangDao;
import dao.MstCobaDao;
import dao.MstCustomerDao;
import dao.MstKaryawanDao;
import dto.MstBarangDto;
import dto.MstCustomerDto;
import dto.MstKaryawanDto;
import dto.MstKotaDto;
import dto.MstProvinsiDto;
import dto.MstSupplierDto;
import entity.MstCoba;
import entity.MstCustomer;
import entity.MstCustomerPK;
import entity.MstKota;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class tes {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("/META-INF/spring/app-config.xml");				
		System.out.println("Test Database");
		MstCustomerDao customerDao = ctx.getBean(MstCustomerDao.class);
		MstCustomerSvc customerSvc = ctx.getBean(MstCustomerSvc.class);
		
		MstBarangDao barangDao = ctx.getBean(MstBarangDao.class);
		MstBarangSvc barangSvc = ctx.getBean(MstBarangSvc.class);
		
		MstKaryawanDao karyawanDao = ctx.getBean(MstKaryawanDao.class);
		
		MstCobaDao cobaDao = ctx.getBean(MstCobaDao.class);
		
		
//		//MENAMPILKAN KE DATABASE
//		List<MstCustomer> customers = customerDao.findAll();
//		for(MstCustomer customer : customers)
//		{
//			System.out.println("Nama Customer : " + customer.getNamaCustomer());
//			System.out.println("Kode Kota : " + customer.getKodeKota());
//			System.out.println("Alamat : " + customer.getAlamatCustomer());
//			System.out.println("Email : " + customer.getEmailCustomer());
//			System.out.println("Jenis Kelamin : " + customer.getJenisKelamin());
//			System.out.println("Kode Customer : "+customer.getKodeCustomer() + "\n");
//		}
		
		//INSERT dan UPDATE DATA KE DATABASE, INGAT KODE HARUS SAMA
//		MstCustomer customer = new MstCustomer();
//		customer.setKodeCustomer("C00003");
//		customer.setNamaCustomer("Ghali");
//		customer.setEmailCustomer("ghaliarkan@gmail.com");
//		customer.setAlamatCustomer("Medan");
//		customer.setJenisKelamin("Laki-Laki");
//		customer.setKodeKota("K001");
//		customerDao.save(customer);

//		//LIAT DATA KEMBALI
//		for(MstCustomer liat : customers)
//		{
//			System.out.println(liat);
//		}
//		
//		//FIND ONE FROM DATA
//		MstCustomerPK customerPK = new MstCustomerPK();
//		customerPK.setKodeCustomer("C00003");
//		MstCustomer mstCustomer = customerDao.findOne(customerPK);
//		System.out.println("Nama : " + mstCustomer.getNamaCustomer());
		
//		MstCustomer mstCustomer = new MstCustomer();
//		mstCustomer.setKodeCustomer("C00003");
//		customerDao.delete(mstCustomer);
		
		//CODE UNTUK MENGAMBIL DATA DARI OBJECT BERDASARKAN KODEKOTA(LIAT MSTCUSTOMERDAO)
//		List<Object[]> objects = customerDao.findAllCustomer();
//		for(Object[] ambil : objects)
//		{
//			MstCustomer mstCustomer = (MstCustomer) ambil[0];
//			String namaKota = (String) ambil[1];
//			System.out.println("Kode Customer : " +
//			mstCustomer.getKodeCustomer());
//			System.out.println("Nama Kota : " + namaKota);
//		}
		
//		MstCustomer customer = customerDao.findOneCustomer("Ghali");
//		System.out.println(customer.getJenisKelamin());
		
		//customer
//		List<MstCustomerDto> simpan = customerSvc.findAllCustomer();
//		for(MstCustomerDto ambil : simpan)
//		{
//			System.out.println(ambil.getKodeCustomer());
//			System.out.println(ambil.getNamaCustomer());
//			System.out.println(ambil.getJenisKelamin());
//			System.out.println(ambil.getAlamatCustomer());
//			System.out.println(ambil.getNamaKota());
//			System.out.println();
//		}
		
		//barang
//		List<MstBarangDto> save = barangSvc.findAllBarang();
//		for(MstBarangDto take : save)
//		{
//			System.out.println(take.getNamaSupplier());
//		}
		
//		MstKaryawanSvc karyawanSvc = ctx.getBean(MstKaryawanSvc.class);
//		//karyawan
//		List<MstKaryawanDto> simpan = karyawanSvc.findAllKaryawan();
//		for(MstKaryawanDto ambil : simpan)
//		{
//			System.out.println(ambil.getKodeKaryawan());
//			System.out.println(ambil.getNamaKaryawan());
//		}
		
//		MstKotaSvc kotaSvc = ctx.getBean(MstKotaSvc.class);
//		//kota
//		List<MstKotaDto> simpan = kotaSvc.findAllKota();
//		for(MstKotaDto ambil : simpan)
//		{
//			System.out.println(ambil.getKodeKota());
//			System.out.println(ambil.getKodeProvinsi());
//			System.out.println(ambil.getNamaKota());
//		}
		
//		MstProvinsiSvc provinsiSvc = ctx.getBean(MstProvinsiSvc.class);
//		//provinsi
//		List<MstProvinsiDto> simpan = provinsiSvc.findAllProvinsi();
//		for(MstProvinsiDto ambil : simpan)
//		{
//			System.out.println(ambil.getKodeProvinsi());
//			System.out.println(ambil.getNamaProvinsi());
//		}
		
//		MstSupplierSvc supplierSvc = ctx.getBean(MstSupplierSvc.class);
//		//supplier
//		List<MstSupplierDto> simpan = supplierSvc.findAllSupplier();
//		for(MstSupplierDto ambil : simpan)
//		{
//			System.out.println(ambil.getNamaSupplier());
//			System.out.println(ambil.getAlamatSupplier());
//		}
		
//		//INSERT dan UPDATE DATA KE DATABASE, INGAT KODE HARUS SAMA
//		MstCustomer customer = new MstCustomer();
//		customer.setKodeCustomer("C003");
//		customer.setNamaCustomer("Arkani");
//		customer.setEmailCustomer("ghaliarkaniii@gmail.com");
//		customer.setAlamatCustomer("Medan");
//		customer.setJenisKelamin("Laki-Laki");
//		customer.setKodeKota("K002");
//		customerDao.save(customer);
		
		//TAMPILKAN CUSTOMER
//		List<MstCustomerDto> simpan = customerSvc.findAllCustomer();
//		for(MstCustomerDto ambil : simpan)
//		{
//			System.out.println(ambil.getKodeCustomer());
//			System.out.println(ambil.getNamaCustomer());
//			System.out.println(ambil.getJenisKelamin());
//			System.out.println(ambil.getAlamatCustomer());
//			System.out.println(ambil.getNamaKota());
//			System.out.println();
//		}
		
		
		//UPDATE CUSTOMER
//		MstCustomerDto updateCustomer = new MstCustomerDto();
//		updateCustomer.setAlamatCustomer("Jakarta Pusat");
//		updateCustomer.setEmailCustomer("ghaliarkanie@gmail.com");
//		updateCustomer.setKodeCustomer("C003");
//		updateCustomer.setKodeKota("K005");
//		updateCustomer.setNamaCustomer("Ghali Ganteng");
//		updateCustomer.setJenisKelamin("Pria");
//		customerSvc.update(updateCustomer);
		
//		//SAVE BARANG
//		MstBarangDto saveBarang = new MstBarangDto();
//		saveBarang.setKodeBarang("B40");
//		saveBarang.setKodeSupplier("coba"); //-->ini harus 'coba' karena di DAO saya bikin join menggunakan kode supplier 
//		saveBarang.setNamaBarang("Bakwan");
//		barangSvc.save(saveBarang);
		
//		List<MstBarangDto> simpan = barangSvc.findAllBarang();
//		for(MstBarangDto ambil : simpan)
//		{
//			System.out.println(ambil.getKodeBarang());
//			System.out.println(ambil.getKodeSupplier());
//			System.out.println(ambil.getNamaBarang());
//			System.out.println();
//		}
		
//		//UPDATE BARANG
//		MstBarangDto saveBarang = new MstBarangDto();
//		saveBarang.setKodeBarang("B40");
//		saveBarang.setKodeSupplier("coba"); //-->ini harus 'coba' karena di DAO saya bikin join menggunakan kode supplier 
//		saveBarang.setNamaBarang("Gehu Pedes");
//		barangSvc.update(saveBarang);
		
//		//DELETE CUSTOMER
//		MstCustomerDto hapusCustomer = new MstCustomerDto();
//		hapusCustomer.setKodeCustomer("C00003");
//		customerSvc.delete(hapusCustomer);
		
//		//FIND DATA CUSTOMER
//		List<MstCustomerDto> cariCustomer = customerSvc.findDataCustomer("03");
//		for(MstCustomerDto tampung : cariCustomer)
//		{
//			System.out.println("Kode Customer : " + tampung.getKodeCustomer());
//			System.out.println("Nama Customer : " +tampung.getNamaCustomer());
//			System.out.println("Jenis Kelamin Customer : " +tampung.getJenisKelamin());
//			System.out.println("Alamat Customer : " +tampung.getAlamatCustomer());
//			System.out.println("Email Customer : " +tampung.getEmailCustomer());
//		}
		
//		//TEST MASUK KE DB AUTOINCREMENT
//		MstCoba mstCoba = new MstCoba();
//		mstCoba.setNama("Ghali Ganteng");
//		cobaDao.save(mstCoba);
		
		
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		try
		{
			df.setLenient(false);
			String tanggal = ("06/11/2018");
			Date tanggalLahir = df.parse(tanggal);
			System.out.println(tanggalLahir);
		}
		catch(Exception e)
		{
			System.out.println("Error");
		}
		
	}

}
