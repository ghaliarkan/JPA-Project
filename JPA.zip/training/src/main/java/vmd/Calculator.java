package vmd;

import java.util.List;

import org.zkoss.bind.annotation.BindingParam;
import org.zkoss.bind.annotation.Command;
import org.zkoss.bind.annotation.Init;
import org.zkoss.bind.annotation.NotifyChange;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zk.ui.select.annotation.WireVariable;

import dto.MstCustomerDto;
import service.MstCustomerSvc;


public class Calculator {

	double hasil;
	String textbox = "";
	String operator = "";
	double angka;
	double angka2;
	
	public double getHasil() {
		return hasil;
	}
	public void setHasil(double hasil) {
		this.hasil = hasil;
	}
	public String getTextbox() {
		return textbox;
	}
	public void setTextbox(String textbox) {
		this.textbox = textbox;
	}
	public String getOperator() {
		return operator;
	}
	public void setOperator(String operator) {
		this.operator = operator;
	}
	
	public double getAngka() {
		return angka;
	}
	public void setAngka(double angka) {
		this.angka = angka;
	}
	
	@NotifyChange("textbox")
	@Command
	public void inputOperator(@BindingParam("input") String input)
	{
		operator = input;
		angka = Double.parseDouble(textbox);
		textbox = "";
	}
	
	@NotifyChange("textbox")
	@Command
	public void inputNumber(@BindingParam("input") String input)
	{
		textbox += input;
	}
	
	@NotifyChange("textbox")
	@Command
	public void result()
	{
		if(operator.equals("+"))
		{
			angka2 = Double.parseDouble(textbox);
			textbox= angka + angka2 +"";
		}
		else if(operator.equals("-"))
		{
			angka2 = Double.parseDouble(textbox);
			textbox= angka - angka2 +"";
		}
		else if(operator.equals("x"))
		{
			angka2 = Double.parseDouble(textbox);
			textbox= angka * angka2 +"";
		}
		else if(operator.equals("÷"))
		{
			angka2 = Double.parseDouble(textbox);
			textbox= angka / angka2 +"";
		}
		else if(operator.equals("^"))
		{
			angka2 = Double.parseDouble(textbox);
//			for(int i = 0; i<=angka2; i++ )
//			{
//				double simpan = angka;
//				textbox = angka*angka + "";
//				simpan += angka*Double.parseDouble(textbox);
//				textbox = String.valueOf(simpan);
//			}
			textbox = String.valueOf(Math.pow(angka, angka2));
		}
		
	}
	
	@NotifyChange("textbox")
	@Command
	public void percent(@BindingParam("input") String input)
	{
		if(input.equals("%"))
		{
			operator = input;
			angka = Double.parseDouble(textbox);
			textbox = angka * 0.01 +"";
		}
	}
	
	@NotifyChange("textbox")
	@Command
	public void  plusMinus() {
		double plusminus = Double.parseDouble(textbox);
		textbox =  plusminus *(-1) +"";
	}
	
	@NotifyChange("textbox")
	@Command
	public void clear()
	{
		textbox = "";
	}
	
	@NotifyChange("textbox")
	@Command
	public void akar()
	{
		angka = Double.parseDouble(textbox);
		textbox = String.valueOf(Math.sqrt(angka));
	}
	
	@NotifyChange("textbox")
	@Command
	public void hapus()
	{
		textbox = textbox.substring(0, (textbox.length()-1));
	}
	
//	@NotifyChange("textbox")
//	@Command
//	public void pangkat(@BindingParam("input") String input)
//	{
//		angka = Double.parseDouble(textbox);
//		for(int i = 0; i<=Integer.parseInt(input); i++ )
//		{
//			textbox= angka*angka + "";
//		}
//	}
	
}
