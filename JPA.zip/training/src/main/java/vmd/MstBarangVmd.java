package vmd;

import java.util.List;

import org.zkoss.bind.annotation.Init;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zk.ui.select.annotation.WireVariable;

import dto.MstBarangDto;
import service.MstBarangSvc;

@VariableResolver(org.zkoss.zkplus.spring.DelegatingVariableResolver.class)
public class MstBarangVmd {

	@WireVariable
	private MstBarangSvc mstBarangSvc;
	
	private List<MstBarangDto> mstBarangDtos;
	private MstBarangDto mstBarangDto;
	public List<MstBarangDto> getMstBarangDtos() {
		return mstBarangDtos;
	}
	public void setMstBarangDtos(List<MstBarangDto> mstBarangDtos) {
		this.mstBarangDtos = mstBarangDtos;
	}
	public MstBarangDto getMstBarangDto() {
		return mstBarangDto;
	}
	public void setMstBarangDto(MstBarangDto mstBarangDto) {
		this.mstBarangDto = mstBarangDto;
	}
	
	@Init
	public void load()
	{
		mstBarangDtos = mstBarangSvc.findAllBarang();
	}
}
