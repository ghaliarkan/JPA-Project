package vmd;

import java.util.List;

import org.zkoss.bind.annotation.Init;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zk.ui.select.annotation.WireVariable;

import dto.MstKaryawanDto;
import service.MstKaryawanSvc;

@VariableResolver(org.zkoss.zkplus.spring.DelegatingVariableResolver.class)
public class MstKaryawanVmd {

	@WireVariable
	private MstKaryawanSvc mstKaryawanSvc;
	
	private List<MstKaryawanDto> mstKaryawanDtos;
	private MstKaryawanDto mstKaryawanDto;
	public List<MstKaryawanDto> getMstKaryawanDtos() {
		return mstKaryawanDtos;
	}
	public void setMstKaryawanDtos(List<MstKaryawanDto> mstKaryawanDtos) {
		this.mstKaryawanDtos = mstKaryawanDtos;
	}
	public MstKaryawanDto getMstKaryawanDto() {
		return mstKaryawanDto;
	}
	public void setMstKaryawanDto(MstKaryawanDto mstKaryawanDto) {
		this.mstKaryawanDto = mstKaryawanDto;
	}
	
	@Init
	public void load()
	{
		mstKaryawanDtos = mstKaryawanSvc.findAllKaryawan();
	}
}
