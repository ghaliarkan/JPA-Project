package vmd;

import java.util.List;

import org.zkoss.bind.BindUtils;
import org.zkoss.bind.annotation.Command;
import org.zkoss.bind.annotation.Init;
import org.zkoss.zk.ui.Executions;
import org.zkoss.zk.ui.Session;
import org.zkoss.zk.ui.Sessions;
import org.zkoss.zk.ui.event.EventListener;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zk.ui.select.annotation.WireVariable;
import org.zkoss.zk.ui.util.Clients;
import org.zkoss.zul.Messagebox;
import org.zkoss.zul.Messagebox.Button;
import org.zkoss.zul.Messagebox.ClickEvent;

import service.MstCustomerSvc;
import dto.MstCustomerDto;

@VariableResolver(org.zkoss.zkplus.spring.DelegatingVariableResolver.class)
public class MstCustomerVmd {

	@WireVariable
	private MstCustomerSvc mstCustomerSvc;
	
	private List<MstCustomerDto> mstCustomerDtos;
	private MstCustomerDto mstCustomerDto;
	private String cari;
	
	
	
	public String getCari() {
		return cari;
	}
	public void setCari(String cari) {
		this.cari = cari;
	}
	public List<MstCustomerDto> getMstCustomerDtos() {
		return mstCustomerDtos;
	}
	public void setMstCustomerDtos(List<MstCustomerDto> mstCustomerDtos) {
		this.mstCustomerDtos = mstCustomerDtos;
	}
	public MstCustomerDto getMstCustomerDto() {
		return mstCustomerDto;
	}
	public void setMstCustomerDto(MstCustomerDto mstCustomerDto) {
		this.mstCustomerDto = mstCustomerDto;
	}
	
	@Init
	public void load()
	{
		mstCustomerDtos = mstCustomerSvc.findAllCustomer();
	}
	
	@Command("add")
	public void add()
	{
		mstCustomerDto = new MstCustomerDto();
		Sessions.getCurrent().setAttribute("obj", mstCustomerDto);
		Executions.sendRedirect("/MstCustomerDetail.zul");
	}
	
	@Command("edit")
	public void edit()
	{
		if(mstCustomerDto == null)
		{
			Messagebox.show("Pilih data yang akan di edit");
		}
		else
		{
			Sessions.getCurrent().setAttribute("obj", mstCustomerDto);
			Executions.sendRedirect("/MstCustomerDetail.zul");
		}
		
	}
	
	@Command("delete")
	public void delete()
	{
		if(mstCustomerDto == null)
		{
			Messagebox.show("Pilih data yang akan di delete");
		}
		else
		{
			Messagebox.show("Apakah anda yakin ingin menghapus ?", "perhatian",
					new Button[] { Button.YES, Button.NO },
					Messagebox.QUESTION, Button.NO,
					new EventListener<Messagebox.ClickEvent>() {
						
						@Override
						public void onEvent(ClickEvent event) throws Exception {
							// TODO Auto-generated method stub
							if(Messagebox.ON_YES.equals(event.getName()))
							{
								mstCustomerSvc.delete(mstCustomerDto);
								mstCustomerDtos.remove(mstCustomerDto);
								BindUtils.postNotifyChange(null, null, MstCustomerVmd.this, "mstCustomerDtos");;
								Clients.showNotification("Data berhasil di delete", Clients.NOTIFICATION_TYPE_INFO, null, null, 500);
								Sessions.getCurrent().setAttribute("obj", mstCustomerDto);
								Executions.sendRedirect("/MstCustomer.zul");
							}
						}
					});
		}
	}
	
	@Command("cari")
	public void cari()
	{
		List<MstCustomerDto> mstCustomerCari = mstCustomerSvc.findDataCustomer(cari);
		if(mstCustomerCari.size() > 0)
		{
			mstCustomerDtos = mstCustomerCari;
			BindUtils.postNotifyChange(null, null, this, "mstCustomerDtos");
		}
		else
		{
			Messagebox.show("Data tidak ditemukan");
		}
	}
}
