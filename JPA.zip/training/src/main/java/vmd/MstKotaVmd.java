package vmd;

import java.util.List;

import org.zkoss.bind.annotation.Init;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zk.ui.select.annotation.WireVariable;

import dto.MstKotaDto;
import service.MstKotaSvc;

@VariableResolver(org.zkoss.zkplus.spring.DelegatingVariableResolver.class)
public class MstKotaVmd {
	
	@WireVariable
	private MstKotaSvc mstKotaSvc;
	
	private List<MstKotaDto> mstKotaDtos;
	private MstKotaDto mstKotaDto;
	
	public List<MstKotaDto> getMstKotaDtos() {
		return mstKotaDtos;
	}

	public void setMstKotaDtos(List<MstKotaDto> mstKotaDtos) {
		this.mstKotaDtos = mstKotaDtos;
	}



	public MstKotaDto getMstKotaDto() {
		return mstKotaDto;
	}



	public void setMstKotaDto(MstKotaDto mstKotaDto) {
		this.mstKotaDto = mstKotaDto;
	}



	@Init
	public void load()
	{
		mstKotaDtos = mstKotaSvc.findAllKota();
	}

}
