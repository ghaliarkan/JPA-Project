package vmd;

import java.util.List;

import org.zkoss.bind.annotation.Init;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zk.ui.select.annotation.WireVariable;

import dto.MstSupplierDto;
import service.MstSupplierSvc;

@VariableResolver(org.zkoss.zkplus.spring.DelegatingVariableResolver.class)
public class MstSupplierVmd {
	
	@WireVariable
	private MstSupplierSvc mstSupplierSvc;
	
	private List<MstSupplierDto> mstSupplierDtos;
	private MstSupplierDto mstSupplierDto;
	
	
	
	public List<MstSupplierDto> getMstSupplierDtos() {
		return mstSupplierDtos;
	}



	public void setMstSupplierDtos(List<MstSupplierDto> mstSupplierDtos) {
		this.mstSupplierDtos = mstSupplierDtos;
	}



	public MstSupplierDto getMstSupplierDto() {
		return mstSupplierDto;
	}



	public void setMstSupplierDto(MstSupplierDto mstSupplierDto) {
		this.mstSupplierDto = mstSupplierDto;
	}



	@Init
	public void load()
	{
		mstSupplierDtos = mstSupplierSvc.findAllSupplier();
	}

}
