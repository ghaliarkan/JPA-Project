package vmd;

import java.util.List;

import org.zkoss.bind.annotation.Init;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zk.ui.select.annotation.WireVariable;

import dto.MstProvinsiDto;
import service.MstProvinsiSvc;

@VariableResolver(org.zkoss.zkplus.spring.DelegatingVariableResolver.class)
public class MstProvinsiVmd {
	
	@WireVariable
	private MstProvinsiSvc mstProvinsiSvc;
	
	private List<MstProvinsiDto> mstProvinsiDtos;
	private MstProvinsiDto mstProvinsiDto;
	
	
	public List<MstProvinsiDto> getMstProvinsiDtos() {
		return mstProvinsiDtos;
	}


	public void setMstProvinsiDtos(List<MstProvinsiDto> mstProvinsiDtos) {
		this.mstProvinsiDtos = mstProvinsiDtos;
	}


	public MstProvinsiDto getMstProvinsiDto() {
		return mstProvinsiDto;
	}


	public void setMstProvinsiDto(MstProvinsiDto mstProvinsiDto) {
		this.mstProvinsiDto = mstProvinsiDto;
	}


	@Init
	public void load()
	{
		mstProvinsiDtos = mstProvinsiSvc.findAllProvinsi();
	}

}
