package vmd;

import java.util.ArrayList;
import java.util.List;

import org.zkoss.bind.annotation.Command;
import org.zkoss.bind.annotation.Init;
import org.zkoss.bind.annotation.NotifyChange;
import org.zkoss.zk.ui.Executions;
import org.zkoss.zk.ui.Sessions;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zk.ui.select.annotation.WireVariable;
import org.zkoss.zk.ui.util.Clients;
import org.zkoss.zul.Messagebox;

import dto.MstCustomerDto;
import dto.MstKotaDto;
import dto.MstProvinsiDto;
import service.MstCustomerSvc;
import service.MstKotaSvc;
import service.MstProvinsiSvc;

@VariableResolver(org.zkoss.zkplus.spring.DelegatingVariableResolver.class)
public class MstCustomerDetailVmd {

	@WireVariable
	private MstCustomerSvc mstCustomerSvc;
	@WireVariable
	private MstKotaSvc mstKotaSvc;
	@WireVariable
	private MstProvinsiSvc mstProvinsiSvc;
	
	private List<MstCustomerDto> mstCustomerDtos = new ArrayList<MstCustomerDto>();
	private MstCustomerDto mstCustomerDto = new MstCustomerDto();
	private List<MstKotaDto> mstKotaDtos = new ArrayList<MstKotaDto>();
	private MstKotaDto mstKotaDto = new MstKotaDto();
	private List<MstProvinsiDto> mstProvinsiDtos = new ArrayList<MstProvinsiDto>();
	private MstProvinsiDto mstProvinsiDto = new MstProvinsiDto();
	public List<MstCustomerDto> getMstCustomerDtos() {
		return mstCustomerDtos;
	}
	public void setMstCustomerDtos(List<MstCustomerDto> mstCustomerDtos) {
		this.mstCustomerDtos = mstCustomerDtos;
	}
	public MstCustomerDto getMstCustomerDto() {
		return mstCustomerDto;
	}
	public void setMstCustomerDto(MstCustomerDto mstCustomerDto) {
		this.mstCustomerDto = mstCustomerDto;
	}
	public List<MstKotaDto> getMstKotaDtos() {
		return mstKotaDtos;
	}
	public void setMstKotaDtos(List<MstKotaDto> mstKotaDtos) {
		this.mstKotaDtos = mstKotaDtos;
	}
	public MstKotaDto getMstKotaDto() {
		return mstKotaDto;
	}
	public void setMstKotaDto(MstKotaDto mstKotaDto) {
		this.mstKotaDto = mstKotaDto;
	}
	public List<MstProvinsiDto> getMstProvinsiDtos() {
		return mstProvinsiDtos;
	}
	public void setMstProvinsiDtos(List<MstProvinsiDto> mstProvinsiDtos) {
		this.mstProvinsiDtos = mstProvinsiDtos;
	}
	public MstProvinsiDto getMstProvinsiDto() {
		return mstProvinsiDto;
	}
	public void setMstProvinsiDto(MstProvinsiDto mstProvinsiDto) {
		this.mstProvinsiDto = mstProvinsiDto;
	}
	
	@Init
	public void load()
	{
		mstCustomerDto = (MstCustomerDto) Sessions.getCurrent().getAttribute("obj");
		
		if(mstCustomerDto.getKodeCustomer() != null)
		{
			mstProvinsiDtos = mstProvinsiSvc.findAllProvinsi();
			mstKotaDtos = mstKotaSvc.findAllKota();
			mstKotaDto = mstKotaSvc.findOneObjectKota(mstCustomerDto.getKodeKota());	
			mstProvinsiDto = mstProvinsiSvc.findOne(mstKotaDto.getKodeProvinsi());
			if(mstProvinsiDto != null)
			{
				mstProvinsiDto.setKodeProvinsi(mstProvinsiDto.getKodeProvinsi());
				mstProvinsiDto.setNamaProvinsi(mstProvinsiDto.getNamaProvinsi());
			}
		}
		else
		{
			mstProvinsiDtos = mstProvinsiSvc.findAllProvinsi();
		}
		
	}
	
	@NotifyChange({"mstKotaDto", "mstKotaDtos", "mstProvinsiDto"})
	@Command("findCity")
	public void findCity()
	{
		mstKotaDto = null;
		mstKotaDtos = mstKotaSvc.findKotaByProvinsi(mstProvinsiDto.getKodeProvinsi());
	}
	
	
	@Command("save")
	public void save()
	{
		MstCustomerDto findmstCustomerDto = new MstCustomerDto();
		findmstCustomerDto = mstCustomerSvc.findOneCustomer(mstCustomerDto.getKodeCustomer());
		mstCustomerDto.setKodeKota(mstKotaDto.getKodeKota());
		if(findmstCustomerDto.getKodeCustomer() == null)
		{
			mstCustomerSvc.save(mstCustomerDto);
			Clients.showNotification("Data berhasil disimpan", 
					Clients.NOTIFICATION_TYPE_INFO, null, null, 1500);
			Executions.sendRedirect("/MstCustomer.zul");
		}
		
		else if(findmstCustomerDto.getKodeCustomer() != null)
		{
			mstCustomerSvc.update(mstCustomerDto);
			Clients.showNotification("Data berhasil diupdate", 
					Clients.NOTIFICATION_TYPE_INFO, null, null, 1500);
			Executions.sendRedirect("/MstCustomer.zul");
		}
	}
	
	@Command("back")
	public void back()
	{
		Executions.sendRedirect("/MstCustomer.zul");
	}
	
	
}
