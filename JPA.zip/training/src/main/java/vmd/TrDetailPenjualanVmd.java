package vmd;

import java.util.List;

import org.zkoss.bind.annotation.Init;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zk.ui.select.annotation.WireVariable;

import dto.TrDetailPenjualanDto;
import service.TrDetailPenjualanSvc;

@VariableResolver(org.zkoss.zkplus.spring.DelegatingVariableResolver.class)
public class TrDetailPenjualanVmd {

	@WireVariable
	private TrDetailPenjualanSvc trDetailPenjualanSvc;
	
	private List<TrDetailPenjualanDto> trDetailDtos;
	private TrDetailPenjualanDto trDetailDto;
	
	
	
	public List<TrDetailPenjualanDto> getTrDetailDtos() {
		return trDetailDtos;
	}



	public void setTrDetailDtos(List<TrDetailPenjualanDto> trDetailDtos) {
		this.trDetailDtos = trDetailDtos;
	}



	public TrDetailPenjualanDto getTrDetailDto() {
		return trDetailDto;
	}



	public void setTrDetailDto(TrDetailPenjualanDto trDetailDto) {
		this.trDetailDto = trDetailDto;
	}



	@Init
	public void load()
	{
		trDetailDtos = trDetailPenjualanSvc.findAllDetailPenjualan();
	}
}
