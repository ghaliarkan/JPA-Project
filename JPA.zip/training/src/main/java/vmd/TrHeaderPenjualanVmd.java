package vmd;

import java.util.List;

import org.zkoss.bind.annotation.Init;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zk.ui.select.annotation.WireVariable;

import dto.TrHeaderPenjualanDto;
import service.TrHeaderPenjualanSvc;

@VariableResolver(org.zkoss.zkplus.spring.DelegatingVariableResolver.class)
public class TrHeaderPenjualanVmd {
	
	@WireVariable
	private TrHeaderPenjualanSvc trHeaderPenjualanSvc;
	
	private List<TrHeaderPenjualanDto> trHeaderDtos;
	private TrHeaderPenjualanDto trHeaderDto;
	
	
	public List<TrHeaderPenjualanDto> getTrHeaderDtos() {
		return trHeaderDtos;
	}



	public void setTrHeaderDtos(List<TrHeaderPenjualanDto> trHeaderDtos) {
		this.trHeaderDtos = trHeaderDtos;
	}



	public TrHeaderPenjualanDto getTrHeaderDto() {
		return trHeaderDto;
	}



	public void setTrHeaderDto(TrHeaderPenjualanDto trHeaderDto) {
		this.trHeaderDto = trHeaderDto;
	}



	@Init
	public void load()
	{
		trHeaderDtos = trHeaderPenjualanSvc.findAllHeaderPenjualan();
	}

}
