package vmd;

import java.util.ArrayList;
import java.util.List;

import org.zkoss.bind.BindUtils;
import org.zkoss.bind.annotation.Command;
import org.zkoss.bind.annotation.Init;
import org.zkoss.bind.annotation.NotifyChange;
import org.zkoss.zk.ui.Executions;
import org.zkoss.zk.ui.Sessions;
import org.zkoss.zk.ui.event.EventListener;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zk.ui.select.annotation.WireVariable;
import org.zkoss.zk.ui.util.Clients;
import org.zkoss.zul.Messagebox;
import org.zkoss.zul.Messagebox.Button;
import org.zkoss.zul.Messagebox.ClickEvent;

import dto.MstBarangDto;
import dto.MstCustomerDto;
import dto.MstKaryawanDto;
import dto.TrDetailPenjualanDto;
import dto.TrHeaderPenjualanDto;
import service.MstBarangSvc;
import service.MstCustomerSvc;
import service.MstKaryawanSvc;
import service.TrDetailPenjualanSvc;
import service.TrHeaderPenjualanSvc;

@VariableResolver(org.zkoss.zkplus.spring.DelegatingVariableResolver.class)
public class TransaksiDetailVmd {

	@WireVariable
	private TrHeaderPenjualanSvc trHeaderPenjualanSvc;
	@WireVariable
	private TrDetailPenjualanSvc trDetailPenjualanSvc;
	@WireVariable
	private MstCustomerSvc mstCustomerSvc;
	@WireVariable
	private MstKaryawanSvc mstKaryawanSvc;
	@WireVariable
	private MstBarangSvc mstBarangSvc;
	
	private List<TrHeaderPenjualanDto> trHeaderDtos = new ArrayList<TrHeaderPenjualanDto>();
	private TrHeaderPenjualanDto trHeaderDto = new TrHeaderPenjualanDto();
	private List<TrDetailPenjualanDto> trDetailDtos = new ArrayList<TrDetailPenjualanDto>();
	private TrDetailPenjualanDto trDetailDto = new TrDetailPenjualanDto();
	private List<MstCustomerDto> mstCustomerDtos = new ArrayList<MstCustomerDto>();
	private MstCustomerDto mstCustomerDto = new MstCustomerDto();
	private List<MstKaryawanDto> mstKaryawanDtos = new ArrayList<MstKaryawanDto>();
	private MstKaryawanDto mstKaryawanDto = new MstKaryawanDto();
	private List<MstBarangDto> mstBarangDtos = new ArrayList<MstBarangDto>();
	private MstBarangDto mstBarangDto = new MstBarangDto();
	private int hargaTotal = 0;
	private int globalDiskon = 0;
	private int totalGlobal = 0;
	private boolean popUp = false;
	
		
	public int getTotalGlobal() {
		return totalGlobal;
	}
	public void setTotalGlobal(int totalGlobal) {
		this.totalGlobal = totalGlobal;
	}
	public int getGlobalDiskon() {
		return globalDiskon;
	}
	public void setGlobalDiskon(int globalDiskon) {
		this.globalDiskon = globalDiskon;
	}
	public int getHargaTotal() {
		return hargaTotal;
	}
	public void setHargaTotal(int hargaTotal) {
		this.hargaTotal = hargaTotal;
	}
	public boolean isPopUp() {
		return popUp;
	}
	public void setPopUp(boolean popUp) {
		this.popUp = popUp;
	}
	public List<MstBarangDto> getMstBarangDtos() {
		return mstBarangDtos;
	}
	public void setMstBarangDtos(List<MstBarangDto> mstBarangDtos) {
		this.mstBarangDtos = mstBarangDtos;
	}
	public MstBarangDto getMstBarangDto() {
		return mstBarangDto;
	}
	public void setMstBarangDto(MstBarangDto mstBarangDto) {
		this.mstBarangDto = mstBarangDto;
	}
	public List<TrHeaderPenjualanDto> getTrHeaderDtos() {
		return trHeaderDtos;
	}
	public void setTrHeaderDtos(List<TrHeaderPenjualanDto> trHeaderDtos) {
		this.trHeaderDtos = trHeaderDtos;
	}
	public TrHeaderPenjualanDto getTrHeaderDto() {
		return trHeaderDto;
	}
	public void setTrHeaderDto(TrHeaderPenjualanDto trHeaderDto) {
		this.trHeaderDto = trHeaderDto;
	}
	public List<TrDetailPenjualanDto> getTrDetailDtos() {
		return trDetailDtos;
	}
	public void setTrDetailDtos(List<TrDetailPenjualanDto> trDetailDtos) {
		this.trDetailDtos = trDetailDtos;
	}
	public TrDetailPenjualanDto getTrDetailDto() {
		return trDetailDto;
	}
	public void setTrDetailDto(TrDetailPenjualanDto trDetailDto) {
		this.trDetailDto = trDetailDto;
	}
	public List<MstCustomerDto> getMstCustomerDtos() {
		return mstCustomerDtos;
	}
	public void setMstCustomerDtos(List<MstCustomerDto> mstCustomerDtos) {
		this.mstCustomerDtos = mstCustomerDtos;
	}
	public MstCustomerDto getMstCustomerDto() {
		return mstCustomerDto;
	}
	public void setMstCustomerDto(MstCustomerDto mstCustomerDto) {
		this.mstCustomerDto = mstCustomerDto;
	}
	public List<MstKaryawanDto> getMstKaryawanDtos() {
		return mstKaryawanDtos;
	}
	public void setMstKaryawanDtos(List<MstKaryawanDto> mstKaryawanDtos) {
		this.mstKaryawanDtos = mstKaryawanDtos;
	}
	public MstKaryawanDto getMstKaryawanDto() {
		return mstKaryawanDto;
	}
	public void setMstKaryawanDto(MstKaryawanDto mstKaryawanDto) {
		this.mstKaryawanDto = mstKaryawanDto;
	}
	
	
	@Init
	public void load()
	{
		trHeaderDto = (TrHeaderPenjualanDto) Sessions.getCurrent().getAttribute("obj");
		setPopUp(false);
		if(trHeaderDto.getNoNota() != null)
		{
			mstCustomerDtos = mstCustomerSvc.findAllCustomer();
			mstKaryawanDtos = mstKaryawanSvc.findAllKaryawan();
			mstBarangDtos = mstBarangSvc.findAllBarang();
			trHeaderDtos = trHeaderPenjualanSvc.findTransaksi();
			trDetailDtos = trDetailPenjualanSvc.findTrDetail(trHeaderDto.getNoNota());
		}
		else
		{
			trHeaderDtos = trHeaderPenjualanSvc.findAllHeaderPenjualan();
			mstCustomerDtos = mstCustomerSvc.findAllCustomer();
			mstKaryawanDtos = mstKaryawanSvc.findAllKaryawan();
			mstBarangDtos = mstBarangSvc.findAllBarang();
		}
		
	}
	
	@Command("back")
	public void back()
	{
		Executions.sendRedirect("/Transaksi.zul");
	}
	
	@NotifyChange({"popUp", "trDetailDto", "mstBarangDto"})
	@Command("addDetail")
	public void add()
	{
		setPopUp(true);
		mstBarangDto = new MstBarangDto();
		trDetailDto = new TrDetailPenjualanDto();
		//Executions.sendRedirect("/TransaksiDetail.zul");
	}
	
	@Command("backDetail")
	@NotifyChange({"trDetailDto", "mstBarangDto", "popUp"})
	public void back2()
	{
		
		setPopUp(false);
		mstBarangDto = new MstBarangDto();
		trDetailDto = new TrDetailPenjualanDto();
	}
	
	@Command("save")
	public void save()
	{
		TrHeaderPenjualanDto findtrHeaderDto = new TrHeaderPenjualanDto();
		findtrHeaderDto = trHeaderPenjualanSvc.findOneHeader(trHeaderDto.getNoNota());
		trHeaderDto.setKodeCustomer(mstCustomerDto.getKodeCustomer());
		trHeaderDto.setKodeKaryawan(mstKaryawanDto.getKodeKaryawan());
		if(findtrHeaderDto.getNoNota() == null)
		{
			trHeaderPenjualanSvc.save(trHeaderDto);
			Clients.showNotification("Data berhasil disimpan", 
					Clients.NOTIFICATION_TYPE_INFO, null, null, 1500);
			Executions.sendRedirect("/Transaksi.zul");
		}
		
		else if(findtrHeaderDto.getNoNota() != null)
		{
			trHeaderPenjualanSvc.save(trHeaderDto);
			Clients.showNotification("Data berhasil diupdate", 
					Clients.NOTIFICATION_TYPE_INFO, null, null, 1500);
			Executions.sendRedirect("/Transaksi.zul");
		}
	}
	
	@NotifyChange({"trDetailDto", "trDetailDtos", "popUp", "hargaTotal", "totalGlobal", "globalDiskon"})
	@Command("saveDetail")
	public void saveDetail()
	{
		trDetailDto.setKodeBarang(mstBarangDto.getKodeBarang());
		trDetailDto.setNamaBarang(mstBarangDto.getNamaBarang());
		trDetailDtos.add(trDetailDto);
		int total = 0;
		int jumlah = 0;
		for(TrDetailPenjualanDto o : trDetailDtos)
		{
			total += o.getSubtotal();
		}
		
		int totalHarga =0;
		for (TrDetailPenjualanDto o : trDetailDtos) {
				totalHarga += o.getSubtotal();
		}
		if(getGlobalDiskon()==0){
			
			setTotalGlobal(totalHarga);
			
		}else{
			
			jumlah =totalHarga-(totalHarga*getGlobalDiskon()/100);
			setTotalGlobal(jumlah);
		}
		setHargaTotal(total);
		//setTotalGlobal(jumlah);
		mstBarangDto = new MstBarangDto();
		trDetailDto = new TrDetailPenjualanDto();
		setPopUp(false);
	}
	
	@NotifyChange({"totalGlobal", "globalDiskon"})
	@Command("totalGlobal")
	public void totalGlobal(){
		int totalHarga =0;
		for (TrDetailPenjualanDto o : trDetailDtos) {
				totalHarga += o.getSubtotal();
		}
		if(getGlobalDiskon()==0){
			
			setTotalGlobal(totalHarga);
			
		}else{
			int jumlah;
			jumlah =totalHarga-(totalHarga*getGlobalDiskon()/100);
			setTotalGlobal(jumlah);
		}
		
	}
	
	@Command("delete")
	public void delete()
	{
		if(trHeaderDto == null)
		{
			Messagebox.show("Pilih data yang akan di delete");
		}
		else
		{
			Messagebox.show("Apakah anda yakin ingin menghapus ?", "perhatian",
					new Button[] { Button.YES, Button.NO },
					Messagebox.QUESTION, Button.NO,
					new EventListener<Messagebox.ClickEvent>() {
						
						@Override
						public void onEvent(ClickEvent event) throws Exception {
							// TODO Auto-generated method stub
							if(Messagebox.ON_YES.equals(event.getName()))
							{
								trHeaderPenjualanSvc.delete(trHeaderDto);
								trHeaderDtos.remove(trHeaderDto);
								BindUtils.postNotifyChange(null, null, TransaksiDetailVmd.this, "trHeaderDtos");;
								Clients.showNotification("Data berhasil di delete", Clients.NOTIFICATION_TYPE_INFO, null, null, 500);
								Sessions.getCurrent().setAttribute("obj", trHeaderDto);
								Executions.sendRedirect("/TransaksiDetail.zul");
							}
						}
					});
		}
	}
}
