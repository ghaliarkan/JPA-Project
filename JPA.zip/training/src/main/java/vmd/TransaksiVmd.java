package vmd;

import java.util.List;

import org.zkoss.bind.BindUtils;
import org.zkoss.bind.annotation.Command;
import org.zkoss.bind.annotation.Init;
import org.zkoss.bind.annotation.NotifyChange;
import org.zkoss.zk.ui.Executions;
import org.zkoss.zk.ui.Sessions;
import org.zkoss.zk.ui.event.EventListener;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zk.ui.select.annotation.WireVariable;
import org.zkoss.zk.ui.util.Clients;
import org.zkoss.zul.Messagebox;
import org.zkoss.zul.Messagebox.Button;
import org.zkoss.zul.Messagebox.ClickEvent;

import dto.MstCustomerDto;
import dto.TrHeaderPenjualanDto;
import service.TrHeaderPenjualanSvc;

@VariableResolver(org.zkoss.zkplus.spring.DelegatingVariableResolver.class)
public class TransaksiVmd {
	
	@WireVariable
	private TrHeaderPenjualanSvc trHeaderPenjualanSvc;
	
	private List<TrHeaderPenjualanDto> trHeaderDtos;
	private TrHeaderPenjualanDto trHeaderDto;
	private String cari;
	
	
	public String getCari() {
		return cari;
	}



	public void setCari(String cari) {
		this.cari = cari;
	}



	public List<TrHeaderPenjualanDto> getTrHeaderDtos() {
		return trHeaderDtos;
	}



	public void setTrHeaderDtos(List<TrHeaderPenjualanDto> trHeaderDtos) {
		this.trHeaderDtos = trHeaderDtos;
	}



	public TrHeaderPenjualanDto getTrHeaderDto() {
		return trHeaderDto;
	}



	public void setTrHeaderDto(TrHeaderPenjualanDto trHeaderDto) {
		this.trHeaderDto = trHeaderDto;
	}



	@Init
	public void load()
	{
		trHeaderDtos = trHeaderPenjualanSvc.findTransaksi();
	}
	
	@Command("cari")
	public void cari()
	{
		List<TrHeaderPenjualanDto> headerDto = trHeaderPenjualanSvc.findDataHeaderPenjualan(cari);
		if(headerDto.size() > 0)
		{
			trHeaderDtos = headerDto;
			BindUtils.postNotifyChange(null, null, this, "trHeaderDtos");
		}
		else
		{
			Messagebox.show("Data tidak ditemukan");
		}
	}
	
	@Command("add")
	public void add()
	{
		trHeaderDto = new TrHeaderPenjualanDto();
		Sessions.getCurrent().setAttribute("obj", trHeaderDto);
		Executions.sendRedirect("/TransaksiDetail.zul");
	}
	
	@Command("edit")
	public void edit()
	{
		if(trHeaderDto == null)
		{
			Messagebox.show("Pilih data yang akan di edit");
		}
		else
		{
			Sessions.getCurrent().setAttribute("obj", trHeaderDto);
			Executions.sendRedirect("/TransaksiDetail.zul");
		}
		
	}
	
	@Command("delete")
	public void delete()
	{
		if(trHeaderDto == null)
		{
			Messagebox.show("Pilih data yang akan di delete");
		}
		else
		{
			Messagebox.show("Apakah anda yakin ingin menghapus ?", "perhatian",
					new Button[] { Button.YES, Button.NO },
					Messagebox.QUESTION, Button.NO,
					new EventListener<Messagebox.ClickEvent>() {
						
						@Override
						public void onEvent(ClickEvent event) throws Exception {
							// TODO Auto-generated method stub
							if(Messagebox.ON_YES.equals(event.getName()))
							{
								trHeaderPenjualanSvc.delete(trHeaderDto);
								trHeaderDtos.remove(trHeaderDto);
								BindUtils.postNotifyChange(null, null, TransaksiVmd.this, "trHeaderDtos");;
								Clients.showNotification("Data berhasil di delete", Clients.NOTIFICATION_TYPE_INFO, null, null, 500);
								Sessions.getCurrent().setAttribute("obj", trHeaderDto);
								Executions.sendRedirect("/Transaksi.zul");
							}
						}
					});
		}
	}
	
	


}
