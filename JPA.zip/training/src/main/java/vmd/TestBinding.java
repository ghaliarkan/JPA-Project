package vmd;

import org.zkoss.bind.annotation.Command;
import org.zkoss.bind.annotation.NotifyChange;

public class TestBinding {

	int luas;
	int panjang;
	int lebar;
	
	@Command("hitung")
	@NotifyChange("luas")
	public void hitungLuas ()
	{
		luas = panjang * lebar;
		System.out.println("Luasnya adalah : " + luas);
				
	}

	public int getLuas() {
		return luas;
	}

	public void setLuas(int luas) {
		this.luas = luas;
	}

	public int getPanjang() {
		return panjang;
	}

	public void setPanjang(int panjang) {
		this.panjang = panjang;
	}

	public int getLebar() {
		return lebar;
	}

	public void setLebar(int lebar) {
		this.lebar = lebar;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + lebar;
		result = prime * result + luas;
		result = prime * result + panjang;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TestBinding other = (TestBinding) obj;
		if (lebar != other.lebar)
			return false;
		if (luas != other.luas)
			return false;
		if (panjang != other.panjang)
			return false;
		return true;
	}
	
}
